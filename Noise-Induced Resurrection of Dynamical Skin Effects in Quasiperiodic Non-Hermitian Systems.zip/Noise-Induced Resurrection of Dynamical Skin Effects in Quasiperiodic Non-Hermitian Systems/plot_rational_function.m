function plot_rational_function()
    % 定义函数
    f = @(x, a) x ./ (x.^2 + a);
    
    % 设置 x 的范围
    x = linspace(-5, 5, 1000);  % 从 -5 到 5，取 1000 个点
    
    % 定义不同的 a 值
    a_values = [1, 2, 3, 4, 5];  % 可以修改这里调整 a 的取值
    
    % 创建新图形
    figure;
    hold on;  % 保持图形，绘制多条曲线
    
    % 循环绘制不同 a 值的曲线
    colors = lines(length(a_values));  % 使用不同颜色
    for i = 1:length(a_values)
        a = a_values(i);
        y = f(x, a);
        plot(x, y, 'LineWidth', 1.5, 'Color', colors(i, :), ...
             'DisplayName', sprintf('a = %.1f', a));
    end
    
    % 添加标题和标签
    title('函数 f(x) = x / (x^2 + a) 在不同 a 值下的曲线');
    xlabel('x');
    ylabel('f(x)');
    grid on;
    
    % 添加图例
    legend('Location', 'best');
    
    % 调整坐标轴范围（可选）
    ylim([-1, 1]);  % 限制 y 轴范围，使曲线更清晰
    
    hold off;  % 结束绘图
end