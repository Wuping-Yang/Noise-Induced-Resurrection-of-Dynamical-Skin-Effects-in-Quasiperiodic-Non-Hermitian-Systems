clc
clear
jr = 2;
jl = 1;
L=100;
W = 10;

H1 = Hatano_Nelson_H_Periodicity(jr,jl,L,W);
% %H1 = Hatano_Nelson_H_Periodicity2(jr,jl,1000,W);
% 
 EE1=eig(H1);
% figure(1)
%  sz=10;
%  scatter(real(EE1),imag(EE1),sz,'filled','k')
%  hold on


H2=Hatano_Nelson_H(jr,jl,L,W);
%H2=Hatano_Nelson_H2(jr,jl,L,W);
%[V2,E2]=eig(vpa(H2,100));
%[V2,E2]=eig(vpa(H2,32));
[V2,E2]=eig(H2);
% EE2=diag(E2);
% rc1=1;
% rc2=L;
% corner_inverse_participation_number=[];
% LL=L./10;
% sumQ1=0;
% for kk= 1:L
%     for ii= 1:L
%         r=ii;
%         sumQ1=sumQ1+(abs(V2(ii,kk)))^(4)*(-exp(-abs(r-rc1)./LL)+exp(-abs(r-rc2)./LL));
%     end
%     corner_inverse_participation_number=[corner_inverse_participation_number,sumQ1];
%     sumQ1=0;
% end
% sz=30;
% c2=[corner_inverse_participation_number];
% scatter3(real(EE2),imag(EE2),corner_inverse_participation_number',sz,c2,'filled');
% zticks(linspace(-0.25, 0.25, 5)); % linspace生成从0到5之间的6个等分点
% xticks(linspace(-10, 10, 5));
% colorbar
% xlabel('Re(E)');
% ylabel('Im(E)');
% yticks(linspace(-0.5, 0.5, 5)); % linspace生成从0到5之间的6个等分点
% xticks(linspace(-2, 3, 5));
% xlim([-2,3]);
% box on
% ylim([-1.2,1.2])
% xlim([-4,4])
% 
% colors = [229 55 49; 246 170 104; 190 217 144;
%     132 201 173; 30 165 215; 87 80 151] / 255;
% map = GenColormap(colors);
% colormap(map)
% colorbar('Ticks',[min(corner_inverse_participation_number),max(corner_inverse_participation_number)],'YTickLabel',{round(min(corner_inverse_participation_number)),...
%                  round(max(corner_inverse_participation_number))}),
% fontsize(gcf,15,"points")
% box on
% set(gca, 'LineWidth', 1.5);
% grid on
%annotation('arrow',[0.1 0.2],[0.1 0.2],'LineWidth',2)
%title(['L=10000'])

% 限制 colorbar 的刻度数量（例如只显示 5 个刻度）
% c = colorbar;
% c.Ticks = linspace(min(c.Limits), max(c.Limits), 5); % 设置 5 个均匀分布的刻度

%
% Ea1=[1.2,0.2];
% Ea2=[1.5,0.1];
% Ea3=[-0.4,0.4];
% sz=100;
% scatter3(Ea1(1),Ea1(2),10,sz,'r','o','LineWidth',3)
% hold on
% scatter3(Ea2(1),Ea2(2),10,sz,'g','+','LineWidth',3)
% hold on
% scatter3(Ea3(1),Ea3(2),10,sz,'b','x','LineWidth',3)
num = 50;
plot(1:L,abs(V2(:,num)).^2, 'LineWidth', 3)
fontsize(gcf,15,"points")
box on
set(gca, 'LineWidth', 1.5);
grid on
pbaspect([3 1 1]); % 设置特定纵横比（宽:高=2:1）