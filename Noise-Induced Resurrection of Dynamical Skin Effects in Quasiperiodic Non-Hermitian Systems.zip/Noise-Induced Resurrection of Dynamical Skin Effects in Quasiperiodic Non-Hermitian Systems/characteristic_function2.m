clc
clear
% 设置参数
beta = (sqrt(5)-1)/2; % 黄金分割率
sin_pi_beta = sin(pi * beta);
W_values = [2:2:10]; 
sigma = linspace(0.01, 10, 1000); 

% 创建第一个画布（函数图像）
figure(1);
hold on;
xlabel('\sigma', 'FontSize', 12);
ylabel('f(\sigma)', 'FontSize', 12);
title('函数图像', 'FontSize', 14);
grid on;
box on;
yticks(linspace(0,0.2,5)); % 自定义刻度位置

% 创建第二个画布（导函数图像）
figure(2);
hold on;
xlabel('\sigma', 'FontSize', 12);
ylabel('f''(\sigma)', 'FontSize', 12);
title('导函数图像', 'FontSize', 14);
grid on;
box on;

colors = lines(length(W_values)); % 使用不同颜色

for i = 1:length(W_values)
    W = W_values(i);
    C = 8 * W^2 * sin_pi_beta^2;
    D = 16 * W^2 * sin_pi_beta^2;
    
    % 计算函数（添加数值稳定性）
    term = D ./ (sigma.^4 + 1e-16); 
    f = (sigma.^2 / C) .* log(1 + term);
    
    % 计算导数
    f_prime = (sigma ./ (4 * W^2 * sin_pi_beta^2)) .* log(1 + term) ...
        - 8 ./ (sigma.^3 .* (1 + term + 1e-16));
    
    % 在第一个画布绘制函数图像
    figure(1);
    plot(sigma, f, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', ['W=', num2str(W)]);
    
    % 在第二个画布绘制导函数图像
    figure(2);
    plot(sigma, f_prime, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', ['W=', num2str(W)]);
    
    % 寻找极值点（指定搜索区间）
    fun = @(s) (s ./ (4 * W^2 * sin_pi_beta^2)) .* log(1 + D ./ (s.^4 + 1e-16)) ...
        - 8 ./ (s.^3 .* (1 + D ./ (s.^4 + 1e-16)));
    search_interval = [0.1, 20]; % 覆盖整个 sigma 范围
    
    [sigma_extremum, ~, exitflag] = fzero(fun, search_interval);
    
    if exitflag == 1
        f_extremum = (sigma_extremum^2 / C) * log(1 + D / (sigma_extremum^4 + 1e-16));
        
        % 在第一个画布标记极值点
        figure(1);
        plot(sigma_extremum, f_extremum, 'r*', 'MarkerSize', 5, 'LineWidth', 2, 'HandleVisibility', 'off');
        
        % 在第二个画布标记极值点
        figure(2);
        plot(sigma_extremum, 0, 'r*', 'MarkerSize', 5, 'LineWidth', 2, 'HandleVisibility', 'off');
    else
        warning('W=%d 时未找到极值点', W);
    end
end

% 添加图例
figure(1);
legend('Location', 'best', 'FontSize', 10);

figure(2);
legend('Location', 'best', 'FontSize', 10);