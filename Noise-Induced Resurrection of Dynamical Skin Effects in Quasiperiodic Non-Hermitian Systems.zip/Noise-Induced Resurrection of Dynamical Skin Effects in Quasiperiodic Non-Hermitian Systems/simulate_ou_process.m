function ou_process = simulate_ou_process(T, dt, theta, mu, sigma, X0)
    % 参数说明：
    % T: 总时间
    % dt: 时间步长
    % theta: 均值回归速度
    % mu: 长期均值
    % sigma: 波动率
    % X0: 初始值

    % 时间向量
    t = 0:dt:T;

    % 初始化过程
    ou_process = zeros(1, length(t));
    ou_process(1) = X0;

    % 模拟 Wiener 过程（布朗运动）
    dW = sqrt(dt) * randn(1, length(t)-1); % Wiener 增量

    % 欧拉-丸山法模拟 OU 过程
    for i = 2:length(t)
        ou_process(i) = ou_process(i-1) + theta * (mu - ou_process(i-1)) * dt + sigma * dW(i-1);
    end

%     % 绘图
%     figure;
%     plot(t, ou_process, 'LineWidth', 1.5);
%     xlabel('Time');
%     ylabel('X_t');
%     title('Ornstein-Uhlenbeck Process');
%     grid on;
end