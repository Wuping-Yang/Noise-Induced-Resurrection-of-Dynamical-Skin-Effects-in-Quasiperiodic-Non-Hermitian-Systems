clc
clear
jr=2;
jl=1;
L=100;  %L是总共的格点数
W=2;

% 噪声参数设置
T = 100;       % 总时间
dt_min = 0.01;    % 最小时间步
theta = 0.0001;      % 均值回归速度
mu = 0;         % 长期均值
sigma = 1;     % 波动率
X0 = 0.1;       % 初始值

% 创建对数均匀分布的时间点（用于演化）
num_points = 10*T;  % 可以根据需要调整点数
log_t = linspace(log10(dt_min), log10(T), num_points);
t_evo = 10.^log_t;  % 对数均匀分布的时间点

% 创建线性时间点（用于画图）
t_plot = 0:dt_min:T; % 线性时间向量

total_ou_process=zeros(L,length(t_plot));

% 构建初态（局域在体系中心处的一个波包）
initial_state=zeros(L,1);
initial_state(L./2)=1;

% 生成OU过程（在画图时间点上）
for ii=1:L
    total_ou_process(ii,:)= simulate_ou_process_adaptive(t_plot, theta, mu, sigma, X0);
end

T_state=initial_state;
T_state_colletion=zeros(L,length(t_plot));
H_initial=Hatano_Nelson_H(jr,jl,L,W);

% 初始化插值索引
current_plot_idx = 1;

for tt=1:length(t_evo)
    % 计算当前时间步长（注意第一个步长特殊处理）
    if tt == 1
        dt = t_evo(1);
    else
        dt = t_evo(tt) - t_evo(tt-1);
    end
    
    % 构建哈密顿量
    H = H_initial;
    for ii=1:L
        % 使用线性插值获取当前演化时间的噪声值
        noise_val = interp1(t_plot, total_ou_process(ii,:), t_evo(tt), 'linear');
        H(ii,ii)=H(ii,ii)+ noise_val;
    end
    
    % 时间演化
    T_state=expm(-1i*H*dt)*T_state;
    T_state=T_state./norm(T_state);
    
    % 将结果保存到最近的画图时间点
    while current_plot_idx <= length(t_plot) && t_plot(current_plot_idx) <= t_evo(tt)
        T_state_colletion(:,current_plot_idx)=T_state;
        current_plot_idx = current_plot_idx + 1;
    end
end

% 填充剩余的时间点（如果有）
if current_plot_idx <= length(t_plot)
    T_state_colletion(:,current_plot_idx:end) = repmat(T_state, 1, length(t_plot)-current_plot_idx+1);
end

figure(1) 
[X,Y] = meshgrid(1:L,t_plot);
surf(X, Y, abs(T_state_colletion'), 'EdgeColor', 'none');
colormap(jet);
colorbar;
xlabel('Site');
ylabel('Time');
view(2); % 二维视图