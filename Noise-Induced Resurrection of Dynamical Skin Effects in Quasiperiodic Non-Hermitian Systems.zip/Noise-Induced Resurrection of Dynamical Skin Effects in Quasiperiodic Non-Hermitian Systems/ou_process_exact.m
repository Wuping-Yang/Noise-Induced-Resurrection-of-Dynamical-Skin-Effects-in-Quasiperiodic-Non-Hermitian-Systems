function ou_path = ou_process_exact(t, theta, mu, sigma, X0)
    theta = max(theta, 1e-3);  % 防止theta=0
    sigma = min(sigma, 10*theta); % 限制噪声强度
    
    ou_path = zeros(size(t));
    ou_path(1) = X0;
    
    for k = 2:length(t)
        dt_k = t(k) - t(k-1);
        dt_k = min(dt_k, 0.1/theta); % 步长保护
        
        % 精确离散公式
        decay = exp(-theta * dt_k);
        noise_scale = sigma * sqrt((1 - exp(-2*theta*dt_k))/(2*theta));
        ou_path(k) = mu + (ou_path(k-1) - mu) * decay + noise_scale * randn;
    end
end