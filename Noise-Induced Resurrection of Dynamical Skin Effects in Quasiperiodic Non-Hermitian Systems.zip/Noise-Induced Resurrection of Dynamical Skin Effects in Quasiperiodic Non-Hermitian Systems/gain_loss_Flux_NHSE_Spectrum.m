clc
clear
t1=2;
t2=1;
gama=1;
fai1=pi./3;
fai2=-pi./2;
L=50; %L是总共的格点数
W=0;


H_PBC=gain_loss_Flux_NHSE(t1,t2,fai1,fai2,gama,W,L,1);
H_OBC=gain_loss_Flux_NHSE(t1,t2,fai1,fai2,gama,W,L,0);


[~,E_PBC]=eig(H_PBC);
%[V_OBC,E_OBC]=eig(vpa(H_OBC,50));
[V_OBC,E_OBC]=eig(H_OBC);

EE_OBC=diag(E_OBC);
EE_PBC=diag(E_PBC);
figure(1)
scatter(real(EE_OBC),imag(EE_OBC),'filled','r')
hold on
scatter(real(EE_PBC),imag(EE_PBC),'filled','b')

figure(2)
plot(1:2*L,abs(V_OBC(:,40))')