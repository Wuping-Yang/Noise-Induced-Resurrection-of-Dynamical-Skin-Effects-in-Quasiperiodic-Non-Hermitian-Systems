clc
clear
t1=2;
t2=1;
gama=1;
fai1=pi/2;    % 修改为标量除法
fai2=-pi/2;   % 修改为标量除法
L=20;
W=0;
index=0;

% 噪声参数设置
T = 100;
dt = 0.02;
theta = 1;
mu = 0;
sigma = 0;
X0 = 0;
t = 0:dt:T;

total_ou_process = zeros(2*L, length(t));
%initial_state = zeros(2*L, 1);
initial_state = ones(2*L, 1)./2*L;
% initial_state(L) = 0.5;
% initial_state(L+1) = 0.5;

% 并行生成噪声数据
for ii = 1:L
    % 预分配临时变量
    temp = zeros(2, length(t));
    temp(1,:) = simulate_ou_process(T, dt, theta, mu, sigma, X0);
    temp(2,:) = simulate_ou_process(T, dt, theta, mu, sigma, X0);
    % 将结果存入对应位置
    total_ou_process(2*ii-1:2*ii, :) = temp;
end

spread_moment = zeros(1, length(t));
T_state = initial_state;
T_state_colletion = zeros(L, length(t));

% 预计算所有时间步的哈密顿量
H_cell = cell(1, length(t));
parfor tt = 1:length(t)
    H = gain_loss_Flux_NHSE(t1, t2, fai1, fai2, gama, W, L, index);
    for ii = 1:2*L
        H(ii,ii) = H(ii,ii) + 1i*total_ou_process(ii,tt);
    end
    H_cell{tt} = H;
end

% 串行时间演化（无法避免）
T_state = initial_state;
for tt = 1:length(t)
    T_state = eig_expm(-1i*H_cell{tt}*dt,20)*T_state;
    T_state = T_state./norm(T_state);
    state = reshape(abs(T_state).^2, 2, L);
    T_state_colletion(:,tt) = sum(state)';
end

% 可视化部分保持不变
figure(1)
[X,Y] = meshgrid(1:L, t);
surf(X, Y, abs(T_state_colletion'), 'EdgeColor', 'none');
colormap(jet);
colorbar;
xlabel('Site');
ylabel('Time');