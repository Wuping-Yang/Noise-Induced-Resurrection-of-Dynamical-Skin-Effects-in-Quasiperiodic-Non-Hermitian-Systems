function LOG_A=eig_expm(A,pre)
if pre == 0
    [V,D]=eigs(A);
else
    [V,D]=eigs(vpa(A,pre));
end
LOG_A=V*expm(D)*V';