function W = generate_W_matrix(N, sigma, theta, beta, W_param, Delta, J, boundary_type)
% 生成矩阵 W 用于方程 d/dt〈P〉= W〈P〉
% 输入参数:
%   N: 点数，j从1到N
%   sigma: 参数 σ
%   theta: 参数 θ
%   beta: 参数 β
%   W_param: 参数 W（表达式中的 W）
%   Delta: 参数 Δ
%   J: 参数 J
%   boundary_type: 边界类型，'open' 或 'periodic'
% 输出:
%   W: N x N 矩阵

% 计算常数
sigma2_theta2 = sigma^2 * theta^2;
sigma4 = sigma^4;
theta4 = theta^4;
W2_theta4 = W_param^2 * theta4;
sin_beta = sin(pi * beta);
sin2_beta = sin_beta^2;

% 初始化矩阵
W = zeros(N, N);

% 遍历每个点 j
for j = 1:N
    % 计算 Re_Q_{j,j+1}
    if j < N
        arg_plus = pi * beta * (2*j + 1);
        sin2_arg_plus = sin(arg_plus)^2;
        denom_plus = sigma4 + 4 * W2_theta4 * sin2_arg_plus * sin2_beta;
        Re_Q_j_jplus1 = sigma2_theta2 / denom_plus;
    else
        % 对于 j = N，处理边界条件
        if strcmp(boundary_type, 'periodic')
            arg_plus = pi * beta * (2*j + 1);
            sin2_arg_plus = sin(arg_plus)^2;
            denom_plus = sigma4 + 4 * W2_theta4 * sin2_arg_plus * sin2_beta;
            Re_Q_j_jplus1 = sigma2_theta2 / denom_plus;
        else % 开边界
            Re_Q_j_jplus1 = 0;
        end
    end
    
    % 计算 Re_Q_{j,j-1}
    if j > 1
        arg_minus = pi * beta * (2*j - 1);
        sin2_arg_minus = sin(arg_minus)^2;
        denom_minus = sigma4 + 4 * W2_theta4 * sin2_arg_minus * sin2_beta;
        Re_Q_j_jminus1 = sigma2_theta2 / denom_minus;
    else
        % 对于 j = 1，处理边界条件
        if strcmp(boundary_type, 'periodic')
            arg_minus = pi * beta * (2*j - 1);
            sin2_arg_minus = sin(arg_minus)^2;
            denom_minus = sigma4 + 4 * W2_theta4 * sin2_arg_minus * sin2_beta;
            Re_Q_j_jminus1 = sigma2_theta2 / denom_minus;
        else % 开边界
            Re_Q_j_jminus1 = 0;
        end
    end
    
    % 计算系数
    A_j = 2 * (Re_Q_j_jplus1 + Re_Q_j_jminus1) * (Delta + J) * (Delta - J);
    B_j = 2 * Re_Q_j_jplus1 * (Delta + J)^2;
    C_j = 2 * Re_Q_j_jminus1 * (Delta - J)^2;
    
    % 设置矩阵元素
    W(j, j) = A_j;
    
    if j < N
        W(j, j+1) = B_j;
    elseif strcmp(boundary_type, 'periodic')
        % 周期边界条件：最后一个点连接到第一个点
        W(N, 1) = B_j;
    end
    
    if j > 1
        W(j, j-1) = C_j;
    elseif strcmp(boundary_type, 'periodic')
        % 周期边界条件：第一个点连接到最后一个点
        W(1, N) = C_j;
    end
end
end