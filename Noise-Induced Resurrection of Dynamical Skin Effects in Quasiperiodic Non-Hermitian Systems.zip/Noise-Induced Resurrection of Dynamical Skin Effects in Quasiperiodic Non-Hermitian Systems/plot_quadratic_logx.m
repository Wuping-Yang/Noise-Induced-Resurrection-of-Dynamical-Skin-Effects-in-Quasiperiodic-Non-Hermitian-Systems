function plot_quadratic_logx(a, b, c, x_min, x_max, num_points)
% PLOT_QUADRATIC_LOGX 绘制对数横坐标的二次函数曲线
%
% 输入参数:
%   a, b, c - 二次函数系数 (y = a*x^2 + b*x + c)
%   x_min   - x轴最小值 (必须为正数)
%   x_max   - x轴最大值
%   num_points - 绘图点数 (可选，默认为1000)
%
% 示例:
%   plot_quadratic_logx(1, -3, 2, 0.1, 100, 1000)

% 设置默认参数
if nargin < 6
    num_points = 1000;
end

% 验证输入参数
if x_min <= 0
    error('x_min必须为正数，因为对数坐标要求x>0');
end

% 在对数空间生成x值
x_log = logspace(log10(x_min), log10(x_max), num_points);

% 计算对应的y值
y = a*x_log.^2 + b*x_log + c;

% 创建图形
figure;
semilogx(x_log, y, 'b-', 'LineWidth', 2);
grid on;

% 添加标签和标题
xlabel('x (对数坐标)', 'FontSize', 12);
ylabel('y = ax^2 + bx + c', 'FontSize', 12);
title(sprintf('二次函数: y = %.1fx^2 + %.1fx + %.1f', a, b, c), 'FontSize', 14);

% 添加图例
legend(sprintf('y = %.1fx^2 + %.1fx + %.1f', a, b, c), 'Location', 'best');

% 美化图形
set(gca, 'FontSize', 11);
box on;

% 显示函数在特定点的值
fprintf('函数在x=%.2f处的值为: %.4f\n', x_min, a*x_min^2 + b*x_min + c);
fprintf('函数在x=%.2f处的值为: %.4f\n', x_max, a*x_max^2 + b*x_max + c);

% 找出并标记极值点（如果有）
if a ~= 0
    vertex_x = -b/(2*a);
    if vertex_x > x_min && vertex_x < x_max
        vertex_y = a*vertex_x^2 + b*vertex_x + c;
        hold on;
        semilogx(vertex_x, vertex_y, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
        text(vertex_x, vertex_y, sprintf(' 极值点 (%.2f, %.2f)', vertex_x, vertex_y), ...
            'VerticalAlignment', 'bottom', 'FontSize', 10);
        hold off;
    end
end
end