clc
clear
t1=1;
t2=2;
t3=0.2;
gama=3.5;
L=40;
%H_PBC=gain_loss_NHSE(t1,t2,t3,gama,L,1);%这里index取1时，H是PBC的；取0时H是OBC的
H_OBC=gain_loss_NHSE(t1,t2,t3,gama,L,0);

lattice_position=[];
for ii=1:L
    lattice_position=[lattice_position,ii,ii];
end


% EE_OBC=diag(E_OBC);
% EE_PBC=diag(E_PBC);
% figure(1)
% scatter(real(EE_OBC),imag(EE_OBC),'filled','r')
% hold on
% scatter(real(EE_PBC),imag(EE_PBC),'filled','b')

% 噪声参数设置
T = 1000;       % 总时间
dt = 0.1;    % 时间步长
theta = 1.0;  % 均值回归速度
mu = 0.0;     % 长期均值
sigma = 1000;  % 波动率
X0 = 0;     % 初始值
t = 0:dt:T; % 时间向量

total_ou_process=zeros(2*L,length(t));
%构建初态（局域在体系中心处的一个波包）
initial_state=zeros(2*L,1);
initial_state(L)=1;

%定义t时刻的瞬时哈密顿量,并计算演化波函数
for ii=1:L
    total_ou_process(ii,:)= simulate_ou_process(T, dt, theta, mu, sigma, X0);
end

lattice_position=zeros(2*L,1);
for ii=1:L
   lattice_position(2*ii-1)=ii;
   lattice_position(2*ii)=ii;
end

spread_moment=zeros(1,length(t));
T_state=initial_state;

for tt=1:length(t)
    H_OBC=gain_loss_NHSE(t1,t2,t3,gama,L,0);

    for ii=1:2*L
        H_OBC(ii,ii)=H_OBC(ii,ii)+ total_ou_process(ii,tt);
    end
    T_state=expm(-1i*H_OBC*dt)*T_state;
    T_state=T_state./norm(T_state);
    sum1=0;
    sum2=0;
    
    for jj=1:2*L
        sum1 = sum1 + (lattice_position(jj))^2*abs(T_state(jj))^2;
        sum2 = sum2 + lattice_position(jj)*abs(T_state(jj))^2;
    end

    spread_moment(tt)=sqrt(sum1-sum2^2);
    

    %     figure(1)
    %     plot(1:2*L,abs(T_state));
end

figure(1)
plot(1:2*L,abs(T_state));

figure(2)
plot(t,spread_moment);