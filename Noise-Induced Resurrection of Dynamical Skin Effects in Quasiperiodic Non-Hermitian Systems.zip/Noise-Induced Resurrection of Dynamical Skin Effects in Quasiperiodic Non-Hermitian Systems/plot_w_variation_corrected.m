function plot_w_variation_corrected()
    % 定义常数
    beta = (sqrt(5)-1)/2; % 黄金分割率
    theta = 1; % 设定θ=1（归一化）
    
    % 计算常数C
    term1 = sin(pi*beta)^2;
    term2 = 1 - sin(8*pi^2*beta)/(8*pi^2*beta);
    C = term1 * term2;
    
    % W值数组
    W_values = [2, 4, 6, 8, 10];
    colors = lines(length(W_values)); % 不同颜色
    x = linspace(0, 10, 1000); % σ/θ范围0-10
    
    figure; hold on; grid on;
    
    % 遍历每个W值
    for i = 1:length(W_values)
        W = W_values(i);
        D = 2 * W^2 * theta^4 * C; % 修正项包含θ⁴
        
        % 计算函数值 (x = σ/θ)
        numerator = (x * theta).^2 * theta^2; % σ²θ²
        denominator = (x * theta).^4 + D;      % σ⁴ + 2W²θ⁴C
        f = numerator ./ denominator;
        
        % 绘制曲线
        plot(x, f, 'Color', colors(i,:), 'LineWidth', 1.5, ...
             'DisplayName', ['W=', num2str(W)]);
        
        % 计算极值点位置 (x = (D)^{1/4}/θ)
        x_peak = (D)^(1/4) / theta;
        % 计算极值点函数值
        f_peak = ((x_peak * theta)^2 * theta^2) / ((x_peak * theta)^4 + D);
        
        % 标记极值点
        plot(x_peak, f_peak, 'ro', 'MarkerFaceColor', 'r', 'MarkerSize', 6);
    end
    
    % 图形标注
    xlabel('\sigma/\theta');
    ylabel('f(\sigma)');
    title('Function for Different W Values (Corrected)');
    legend('show', 'Location', 'northeast');
    ylim([0, 0.25]);
    set(gca, 'FontSize', 15);
    box on;
    grid on;
    set(gca, 'GridLineStyle', '-', 'LineWidth', 1.2);
    hold off;
end