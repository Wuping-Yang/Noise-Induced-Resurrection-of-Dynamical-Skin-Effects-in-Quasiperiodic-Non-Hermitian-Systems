clc
clear
sigma = 10;    % 参数 σ
theta = 1;    % 参数 θ
beta = (sqrt(5)-1)./2;     % 参数 β
W_param = 10;  % 参数 W（表达式中的 W）
Delta = 0.5;    % 参数 Δ
J = 1.5;        % 参数 J
L=500;
boundary_type1 = 'periodic';
boundary_type2= 'open';
EE1=[];
EE2=[];

H1 = generate_W_matrix(L, sigma, theta, beta, W_param, Delta, J, boundary_type1)';
EE1=eig(H1);

jr = J + Delta;
jl = J - Delta;
H2 = Hatano_Nelson_H_Periodicity(jr,jl,L,W_param);
EE2=eig(H2);

% 创建图形
figure(1)
sz = 20;

% 确定每个数据集的坐标范围，并添加一些边距
margin_factor = 0.05; % 边距系数，可以根据需要调整

x_min1 = min(real(EE1));
x_max1 = max(real(EE1));
y_min1 = min(imag(EE1));
y_max1 = max(imag(EE1));

% 为EE1添加边距
x_range1 = x_max1 - x_min1;
y_range1 = y_max1 - y_min1;
x_min1 = x_min1 - margin_factor * x_range1;
x_max1 = x_max1 + margin_factor * x_range1;
y_min1 = y_min1 - margin_factor * y_range1;
y_max1 = y_max1 + margin_factor * y_range1;

x_min2 = min(real(EE2));
x_max2 = max(real(EE2));
y_min2 = min(imag(EE2));
y_max2 = max(imag(EE2));

% 为EE2添加边距
x_range2 = x_max2 - x_min2;
y_range2 = y_max2 - y_min2;
x_min2 = x_min2 - margin_factor * x_range2;
x_max2 = x_max2 + margin_factor * x_range2;
y_min2 = y_min2 - margin_factor * y_range2;
y_max2 = y_max2 + margin_factor * y_range2;

% 处理可能出现的范围问题（当所有点值相同时）
if y_min2 == y_max2
    y_min2 = y_min2 - 0.1;
    y_max2 = y_max2 + 0.1;
end

if x_min2 == x_max2
    x_min2 = x_min2 - 0.1;
    x_max2 = x_max2 + 0.1;
end

% 创建第一个坐标轴（左侧和底部）
ax1 = axes;
scatter(ax1, real(EE1), imag(EE1), sz, 'filled', 'MarkerFaceColor', [0 0.4470 0.7410]) % 蓝色
xlabel(ax1, 'Real(EE1)')
ylabel(ax1, 'Imag(EE1)')
ax1.XColor = [0 0.4470 0.7410];
ax1.YColor = [0 0.4470 0.7410];

% 设置第一个坐标轴的范围
xlim(ax1, [x_min1, x_max1])
ylim(ax1, [y_min1, y_max1])

% 确保两个坐标轴有相同数量的刻度
num_ticks = 5; % 设置想要的刻度数量

% 设置第一个坐标轴的刻度
set(ax1, 'XTick', linspace(x_min1, x_max1, num_ticks));
set(ax1, 'YTick', linspace(y_min1, y_max1, num_ticks));

% 创建第二个坐标轴（右侧和顶部）
ax2 = axes('Position', ax1.Position, ...
           'XAxisLocation', 'top', ...
           'YAxisLocation', 'right', ...
           'Color', 'none', ...
           'XColor', [0.8500 0.3250 0.0980], ...
           'YColor', [0.8500 0.3250 0.0980]);
hold(ax2, 'on')
scatter(ax2, real(EE2), imag(EE2), sz, 'filled', 'MarkerFaceColor', [0.8500 0.3250 0.0980]) % 橙色
xlabel(ax2, 'Real(EE2)')
ylabel(ax2, 'Imag(EE2)')

% 设置第二个坐标轴的范围
xlim(ax2, [x_min2, x_max2])
ylim(ax2, [y_min2, y_max2])

% 设置第二个坐标轴的刻度
set(ax2, 'XTick', linspace(x_min2, x_max2, num_ticks));
set(ax2, 'YTick', linspace(y_min2, y_max2, num_ticks));

% 应用全局格式设置
fontsize(gcf, 15, "points");
set(ax1, 'LineWidth', 1.5);
set(ax2, 'LineWidth', 1.5);
% grid(ax1, 'on')
% box(ax1, 'on')
% grid(ax2, 'on')
% box(ax2, 'on')
% 
% % 确保第一个坐标轴在最前面
% uistack(ax1, 'top')
% 
% % 调整视图
% hold(ax1, 'off')
% hold(ax2, 'off')
% 
% % 可选：检查是否有数据点超出范围
% fprintf('EE1 X范围: [%.4f, %.4f], 数据点范围: [%.4f, %.4f]\n', ...
%         x_min1, x_max1, min(real(EE1)), max(real(EE1)));
% fprintf('EE1 Y范围: [%.4f, %.4f], 数据点范围: [%.4f, %.4f]\n', ...
%         y_min1, y_max1, min(imag(EE1)), max(imag(EE1)));
% fprintf('EE2 X范围: [%.4f, %.4f], 数据点范围: [%.4f, %.4f]\n', ...
%         x_min2, x_max2, min(real(EE2)), max(real(EE2)));
% fprintf('EE2 Y范围: [%.4f, %.4f], 数据点范围: [%.4f, %.4f]\n', ...
%         y_min2, y_max2, min(imag(EE2)), max(imag(EE2)));