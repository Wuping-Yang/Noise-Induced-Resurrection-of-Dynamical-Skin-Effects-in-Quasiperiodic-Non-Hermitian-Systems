function ou_path = simulate_ou_process_adaptive(t, theta, mu, sigma, X0)
% 输入: t为时间向量, theta均值回归速度, mu长期均值, sigma波动率, X0初始值
ou_path = zeros(size(t));
ou_path(1) = X0;
for k = 2:length(t)
    dt = t(k) - t(k-1);
    decay = exp(-theta * dt);
    ou_path(k) = mu + (ou_path(k-1) - mu) * decay + ...
        sigma * sqrt((1 - exp(-2*theta*dt))/(2*theta)) * randn;
end
end