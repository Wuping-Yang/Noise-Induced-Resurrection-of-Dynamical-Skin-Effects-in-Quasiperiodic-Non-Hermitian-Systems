function plot_f_vs_sigma_linear(w_values, sigma_range, method, M)
% 绘制不同 w 下 f(sigma) 的图像（线性坐标）
% 输入参数:
%   w_values: w 的取值数组 (例如 [0.1, 0.5, 1.0])
%   sigma_range: sigma 的范围 [sigma_min, sigma_max] (例如 [0.1, 10])
%   method: 平均方法 ('integral' 或 'discrete')
%   M: 离散平均时的格点数 (默认为 1e4)
%
% 示例调用:
%   plot_f_vs_sigma_linear([0.5, 1, 2], [0.1, 10], 'integral');
%   plot_f_vs_sigma_linear([0.5, 1, 2], [0.1, 10], 'discrete', 1e5);

if nargin < 4
    M = 1e4; % 默认格点数
end

beta = (sqrt(5)-1)/2; % 黄金分割倒数
theta = 1; % 固定 theta=1
sigma = linspace(sigma_range(1), sigma_range(2), 10000); % 线性间隔采样

figure;
hold on;
colors = lines(length(w_values)); % 不同颜色区分 w

for k = 1:length(w_values)
    w = w_values(k);
    
    if strcmpi(method, 'integral')
        % 解析积分平均 (保留非单调性)
        C = 4 * w^2 * sin(pi*beta)^2;
        f_avg = (sigma/theta) ./ C .* log(1 + C ./ (sigma/theta).^2);
    elseif strcmpi(method, 'discrete')
        % 离散格点平均
        j = 1:M;
        theta_j = 2*pi*beta*j + pi*beta;
        sin2_term = sin(theta_j).^2;
        f_avg = arrayfun(@(s) mean( (s/theta) ./ ( (s/theta)^2 + 4*w^2*sin(pi*beta)^2*sin2_term ) ), sigma);
    else
        error('方法必须是 "integral" 或 "discrete"');
    end
    
    % 绘图（线性坐标）
    plot(sigma, f_avg, 'Color', colors(k,:), 'LineWidth', 1.5, 'DisplayName', sprintf('w=%.2f', w));
end

xlabel('\sigma');
ylabel('f(\sigma)');
title(['空间平均 f(\sigma) (方法: ', method, ', 线性坐标)']);
legend('Location', 'best');
grid on;
xlim([sigma_range(1), sigma_range(2)]);
hold off;
end