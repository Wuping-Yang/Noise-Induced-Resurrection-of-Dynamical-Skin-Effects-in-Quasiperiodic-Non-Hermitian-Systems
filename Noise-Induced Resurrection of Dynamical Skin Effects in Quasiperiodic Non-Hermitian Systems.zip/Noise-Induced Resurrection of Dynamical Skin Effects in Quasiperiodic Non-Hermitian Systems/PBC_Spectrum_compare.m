clc
clear
jr = 2;
jl = 1;
W = 5;

sigma = 10;    % 参数 σ
theta = 1;    % 参数 θ
beta = (sqrt(5)-1)./2;     % 参数 β
W_param = 10;  % 参数 W（表达式中的 W）
Delta = 0.5;    % 参数 Δ
J = 1.5;        % 参数 J
L=3000;
boundary_type1 = 'periodic';
boundary_type2= 'open';

H1 = Hatano_Nelson_H_Periodicity(jr,jl,L,W);

H2 = generate_W_matrix(L, sigma, theta, beta, W_param, Delta, J, 'periodic');
EE1=eig(H1);
EE2=eig(H2);

figure(1)
sz=20;
scatter(real(EE1),imag(EE1),sz,'filled','r')
hold on
scatter(real(EE2),imag(EE2),sz,'filled','b')
xlim([-0.2,0.05])
ylim([-0.06,0.06])
box on
fontsize(gcf,15,"points")
set(gca, 'LineWidth', 1.5);
grid on
xlabel('Re(E)');
ylabel('Im(E)');
