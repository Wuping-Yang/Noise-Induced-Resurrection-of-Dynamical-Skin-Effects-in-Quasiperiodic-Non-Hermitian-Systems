clc
clear
jr = 2;
jl = 1;
L=100;
W = 5;

%这里EE是能量参考点
RE_Ea=-3.2:0.1:3.2;
IM_Ea=-1.2:0.01:1.2;
P_collection = zeros(length(RE_Ea),length(IM_Ea));
ensemble = 100;
for ii=1:length(RE_Ea)
    for jj=1:length(IM_Ea)

        parfor aa = 1:ensemble
            Ea = RE_Ea(ii)+1i*IM_Ea(jj);
            Bott = disorder_HN_Bott(jr,jl,L,W,Ea);
            P_collection(ii,jj) = P_collection(ii,jj) + Bott;
        end

    end
end
P_collection = P_collection./ensemble;
figure(1)
[X,Y]=meshgrid(RE_Ea,IM_Ea);
surface(X,Y,real((P_collection')));
colorbar
xlabel('Re(Ea)')
ylabel('Im(Ea)')
%title('P')
shading interp %使更光滑

