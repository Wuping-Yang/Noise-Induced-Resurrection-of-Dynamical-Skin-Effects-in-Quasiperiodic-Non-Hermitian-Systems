clc
clear
t1=1i;
t2=2*1i;
t3=0.2;
gama=3.5;
W = 0;
L=20;
H_PBC=gain_loss_NHSE(t1,t2,t3,gama,W,L,1);%这里index取1时，H是PBC的；取0时H是OBC的
H_OBC=gain_loss_NHSE(t1,t2,t3,gama,W,L,0);

[~,E_PBC]=eig(H_PBC);
[V_OBC,E_OBC]=eig(H_OBC);

EE_OBC=diag(E_OBC);
EE_PBC=diag(E_PBC);
figure(1)
scatter(real(EE_OBC),imag(EE_OBC),'filled','r')
hold on
scatter(real(EE_PBC),imag(EE_PBC),'filled','b')

figure(2)
plot(1:2*L,abs(V_OBC(:,10))')