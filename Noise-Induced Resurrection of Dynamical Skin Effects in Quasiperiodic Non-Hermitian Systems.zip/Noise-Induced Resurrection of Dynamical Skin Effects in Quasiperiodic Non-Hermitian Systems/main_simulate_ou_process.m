clc
clear
% 参数设置
T = 10;       % 总时间
dt = 0.01;    % 时间步长
theta = 1.0;  % 均值回归速度
mu = 0.0;     % 长期均值
sigma = 1;  % 波动率
X0 = 0;     % 初始值
t = 0:dt:T; % 时间向量

% 模拟 OU 过程
%ou_process = simulate_ou_process(T, dt, theta, mu, sigma, X0);
ou_process = simulate_ou_process_adaptive(t, theta, mu, sigma, X0);

plot(t,ou_process)
box on 
grid on
% %计算OU过程的协方差
% ensemble=1000;
% cov=zeros(1,length(t));
% %
% % for jj=1:length(t)
% %     for ii=1:ensemble
% %         ou_process = simulate_ou_process(T, dt, theta, mu, sigma, X0);
% %         cov(jj)=cov(jj)+ou_process(500)*ou_process(jj);
% %     end
% %     cov(jj)=cov(jj)./ensemble;
% % end
% %
% % plot(t,cov)
% 
% for jj=1:length(t)
%     for ii=1:ensemble
%         ou_process = simulate_ou_process_adaptive(t, theta, mu, sigma, X0);
%         cov(jj) = cov(jj) + ou_process(500)*ou_process(jj);
%     end
% end
% cov=cov./ensemble;
% plot(t,cov)