clc
clear

jr=2;
jl=1;
L=100;  %L是总共的格点数
W=0;

% 噪声参数设置
T = 1000;       % 总时间
dt = 0.01;    % 时间步长
theta = 1.0;  % 均值回归速度
mu = 0.0;     % 长期均值
sigma = 0;  % 波动率
X0 = 0;     % 初始值
t = 0:dt:T; % 时间向量

total_ou_process=zeros(L,length(t));
H=Hatano_Nelson_H(jr,jl,L,W);
%构建初态（局域在体系中心处的一个波包）
initial_state=zeros(L,1);
initial_state(L./2)=1;

%定义t时刻的瞬时哈密顿量,并计算演化波函数
for ii=1:L
    total_ou_process(ii,:)= simulate_ou_process(T, dt, theta, mu, sigma, X0);
end

T_state=initial_state;
for tt=1:length(t)
    for ii=1:L
        H(ii,ii)=H(ii,ii)+ total_ou_process(ii,tt);
    end
    T_state=expm(-1i*H*dt)*T_state;
    T_state=normalize(T_state);
    H=Hatano_Nelson_H(jr,jl,L,W);
%     figure(1)
%     plot(1:L,abs(T_state));
end
figure(1)
plot(1:L,abs(T_state));

%
% AbsE=zeros(1,L);
% [V,E]=eig(H);
% for ii=1:L
%     AbsE(ii)=E(ii,ii);
% end
