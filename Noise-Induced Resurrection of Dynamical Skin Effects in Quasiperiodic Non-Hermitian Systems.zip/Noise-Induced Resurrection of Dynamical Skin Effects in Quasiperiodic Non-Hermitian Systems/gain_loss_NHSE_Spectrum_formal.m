clc
clear
t1=1i;
t2=2*1i;
t3=0.2;
gama=3.5;
L=100;  %L是总共的格点数
W=3;
index=0;

H1 = gain_loss_NHSE(t1,t2,t3,gama,W,L,1);

EE1=eig(H1);
figure(1)
sz=10;
scatter(real(EE1),imag(EE1),sz,'filled','k')
hold on


H2 = gain_loss_NHSE(t1,t2,t3,gama,W,L,0);
%[V2,E2]=eig(vpa(H2,100));
[V2,E2]=eig(vpa(H2,32));
%[V2,E2]=eig(H2);
EE2=diag(E2);
rc1=1;
rc2=2*L;
corner_inverse_participation_number=[];
LL=L./10;
sumQ1=0;
for kk= 1:2*L
    for ii= 1:2*L
        r=ii;
        sumQ1=sumQ1+(abs(V2(ii,kk)))^(4)*(-exp(-abs(r-rc1)./LL)+exp(-abs(r-rc2)./LL));
    end
    corner_inverse_participation_number=[corner_inverse_participation_number,sumQ1];
    sumQ1=0;
end
sz=30;
c2=[corner_inverse_participation_number];
scatter3(real(EE2),imag(EE2),corner_inverse_participation_number',sz,c2,'filled');
% zticks(linspace(-0.25, 0.25, 5)); % linspace生成从0到5之间的6个等分点
% xticks(linspace(-10, 10, 5));
colorbar
xlabel('Re(E)');
ylabel('Im(E)');
% yticks(linspace(-0.5, 0.5, 5)); % linspace生成从0到5之间的6个等分点
% xticks(linspace(-2, 3, 5));
% xlim([-2,3]);
box on
% ylim([-5,5])
% xlim([-0.4,0.4])

colors = [229 55 49; 246 170 104; 190 217 144;
    132 201 173; 30 165 215; 87 80 151] / 255;
map = GenColormap(colors);
colormap(map)
% colorbar('Ticks',[min(corner_inverse_participation_number),max(corner_inverse_participation_number)],'YTickLabel',{round(min(corner_inverse_participation_number)),...
%                  round(max(corner_inverse_participation_number))}),
fontsize(gcf,15,"points")
box on
set(gca, 'LineWidth', 1.5);
grid on
%annotation('arrow',[0.1 0.2],[0.1 0.2],'LineWidth',2)
%title(['L=10000'])

% 限制 colorbar 的刻度数量（例如只显示 5 个刻度）
c = colorbar;
c.Ticks = linspace(min(c.Limits), max(c.Limits), 5); % 设置 5 个均匀分布的刻度

figure(2)
number = 20;
plot(1:2*L,abs(V2(:,number)))
