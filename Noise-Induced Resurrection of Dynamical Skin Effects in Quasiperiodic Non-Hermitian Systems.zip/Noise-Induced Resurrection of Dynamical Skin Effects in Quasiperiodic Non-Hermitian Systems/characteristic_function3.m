clc
clear

% 设置参数
beta = (sqrt(5)-1)/2; % 黄金分割率
theta = 1; % 固定θ=1
sin_pi_beta = sin(pi * beta);
W_values = [2, 4, 6, 8, 10]; 
sigma = linspace(0.01, 10, 1000); % σ范围调整到0.01-5

% 创建画布（函数图像）
figure;
hold on;
xlabel('\sigma', 'FontSize', 12);
ylabel('f(\sigma)', 'FontSize', 12);
title('函数 f(\sigma) = \sigma^2\theta^2 / (\sigma^4 + 2W^2\theta^4\sin^2(\pi\beta))', 'FontSize', 14);
grid on;
box on;

colors = lines(length(W_values)); % 使用不同颜色

for i = 1:length(W_values)
    W = W_values(i);
    
    % 计算函数值
    denominator = sigma.^4 + 2 * W^2 * theta^4 * sin_pi_beta^2;
    f = (sigma.^2 * theta^2) ./ denominator;
    
    % 绘制函数图像
    plot(sigma, f, 'Color', colors(i,:), 'LineWidth', 2, 'DisplayName', ['W=', num2str(W)]);
    
    % 寻找极值点（导数为零的点）
    % 使用解析解：σ^4 = 2W^2θ^4sin^2(πβ)
    sigma_extremum = (2 * W^2 * theta^4 * sin_pi_beta^2)^(1/4);
    f_extremum = (sigma_extremum^2 * theta^2) / (sigma_extremum^4 + 2 * W^2 * theta^4 * sin_pi_beta^2);
    
    % 标记极值点（实心小红点，较小尺寸）
    plot(sigma_extremum, f_extremum, 'ro', 'MarkerSize', 5, 'LineWidth', 1.5, ...
        'MarkerFaceColor', 'r', 'HandleVisibility', 'off');
    
    % 显示极值点信息
    fprintf('W=%d: 极值点位置 σ=%.4f, 函数值 f=%.6f\n', W, sigma_extremum, f_extremum);
end

% 添加图例
legend('Location', 'best', 'FontSize', 10);
%axis([0 25 0 0.25]); % 设置坐标轴范围

% 添加网格
grid on;