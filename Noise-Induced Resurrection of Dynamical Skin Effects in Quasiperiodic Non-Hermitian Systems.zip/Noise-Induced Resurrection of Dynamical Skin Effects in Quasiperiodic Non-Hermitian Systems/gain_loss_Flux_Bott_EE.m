clc
clear
t1=1i;
t2=2*1i;
t3=0.2;
gama=3.5;
L=50;
W=0;

RE_Ea=-0.4:0.01:0.4;
IM_Ea=-4:0.01:4;
P_collection=zeros(length(RE_Ea),length(IM_Ea));
for ii=1:length(RE_Ea)
    parfor jj=1:length(IM_Ea)
        Ea=RE_Ea(ii)+1i*IM_Ea(jj);
        p=gain_loss_Flux_Bott(t1, t2, fai1, fai2, gama, W, L, Ea);
        P_collection(ii,jj)=p;
    end
end

figure(1)
[X,Y]=meshgrid(RE_Ea,IM_Ea);
surface(X,Y,real((P_collection')));
colorbar
xlabel('Re(Ea)')
ylabel('Im(Ea)')
%title('P')
shading interp %使更光滑
yticks(linspace(-4, 4, 5)); % linspace生成从0到5之间的6个等分点
xticks(linspace(-1.2,1.2, 5));
