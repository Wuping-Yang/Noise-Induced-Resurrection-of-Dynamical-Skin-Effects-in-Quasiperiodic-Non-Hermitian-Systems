function Bott=skin_effect_1D_polarization(jr,jl,LL,W,Ea)
H=Hatano_Nelson_H(jr,jl,LL,W);
%h=Hatano_Nelson_H(jr,jl,L/2,W);
%h=Hatano_Nelson_H_Periodicity(jr,jl,L./2,W);
h=H-Ea*eye(LL);
[UA,~,UB] = svd(h);

position_operator=zeros(LL);
for ii=1:LL
    position_operator(ii,ii)=exp(1i*2*pi*(1/LL)*ii);
end

XA=inv(UA)*position_operator*UA
XB=inv(UB)*position_operator*UB;

Bott=trace(logm((XA*inv(XB))))*(2*pi*1i)^(-1);
