clc
clear
% 参数设置
L = 1000;           % 系统尺寸
jr = 1.0;           % 向右跳跃幅度
jl = 0.8;           % 向左跳跃幅度
W_min = 0.5;        % 最小无序强度
W_max = 5.0;        % 最大无序强度
num_W = 20;         % W点数
W_list = linspace(W_min, W_max, num_W);

% 初始化结果存储
right_lyap_E0 = zeros(1, num_W);
left_lyap_E0 = zeros(1, num_W);
right_lyap_ReMax = zeros(1, num_W);
left_lyap_ReMax = zeros(1, num_W);
right_lyap_ReMin = zeros(1, num_W);
left_lyap_ReMin = zeros(1, num_W);

% 主循环：计算不同W下的李雅普诺夫指数
for w_idx = 1:num_W
    fprintf('计算 W=%.2f (%d/%d)\n', W_list(w_idx), w_idx, num_W);
    
    % 生成哈密顿量
    H = Hatano_Nelson_H(jr, jl, L, W_list(w_idx));
    
    % 计算所有本征值
    eigenvalues = eig(H);
    real_parts = real(eigenvalues);
    
    % 选择特定能量点
    [~, idx0] = min(abs(real_parts));       % 实部最接近0的本征值
    [~, idx_max] = max(real_parts);         % 实部最大的本征值
    [~, idx_min] = min(real_parts);         % 实部最小的本征值
    
    E0 = eigenvalues(idx0);
    E_ReMax = eigenvalues(idx_max);
    E_ReMin = eigenvalues(idx_min);
    
    % 计算各能量点的李雅普诺夫指数
    [right_lyap_E0(w_idx), left_lyap_E0(w_idx)] = calc_lyap_for_E(H, L, E0);
    [right_lyap_ReMax(w_idx), left_lyap_ReMax(w_idx)] = calc_lyap_for_E(H, L, E_ReMax);
    [right_lyap_ReMin(w_idx), left_lyap_ReMin(w_idx)] = calc_lyap_for_E(H, L, E_ReMin);
end

% 绘制右李雅普诺夫指数
figure('Position', [100, 100, 800, 600]);
hold on;
plot(W_list, right_lyap_E0, 'LineWidth', 2, 'DisplayName', 'E=0');
plot(W_list, right_lyap_ReMax, 'LineWidth', 2, 'DisplayName', 'Re(E) max');
plot(W_list, right_lyap_ReMin, 'LineWidth', 2, 'DisplayName', 'Re(E) min');
xlabel('无序强度 W');
ylabel('右李雅普诺夫指数');
title('不同能量点的右李雅普诺夫指数 vs 无序强度');
legend('Location', 'best');
grid on;
set(gca, 'FontSize', 12, 'LineWidth', 1.5);
box on;

% 绘制左李雅普诺夫指数
figure('Position', [100, 100, 800, 600]);
hold on;
plot(W_list, left_lyap_E0, 'LineWidth', 2, 'DisplayName', 'E=0');
plot(W_list, left_lyap_ReMax, 'LineWidth', 2, 'DisplayName', 'Re(E) max');
plot(W_list, left_lyap_ReMin, 'LineWidth', 2, 'DisplayName', 'Re(E) min');
xlabel('无序强度 W');
ylabel('左李雅普诺夫指数');
title('不同能量点的左李雅普诺夫指数 vs 无序强度');
legend('Location', 'best');
grid on;
set(gca, 'FontSize', 12, 'LineWidth', 1.5);
box on;