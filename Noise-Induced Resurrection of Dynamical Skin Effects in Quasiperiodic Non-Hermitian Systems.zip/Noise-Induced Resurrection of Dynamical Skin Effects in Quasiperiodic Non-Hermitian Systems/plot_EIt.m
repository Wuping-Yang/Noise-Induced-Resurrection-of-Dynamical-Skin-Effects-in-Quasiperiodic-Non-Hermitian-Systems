function plot_EIt(sigma, W_values)
    % 计算并绘制不同W值下的E[I(t)]函数曲线
    % 输入参数：
    %   sigma: 固定的sigma值
    %   W_values: 包含多个W值的数组
    
    % 创建图形窗口
    figure;
    hold on;
    grid on;
    xlabel('\sigma');
    ylabel('E[I(t)]');
    title(['E[I(t)] for different W values (\sigma = ' num2str(sigma) ')']);
    
    % 定义sigma范围
    sigma_range = linspace(0.1, 5, 100);  % 避免sigma=0
    
    % 为每个W值计算并绘制曲线
    colors = lines(length(W_values));  % 获取不同的颜色
    legend_entries = cell(1, length(W_values));
    
    for i = 1:length(W_values)
        W = W_values(i);
        
        % 计算函数值
        term1 = sqrt(pi) * exp(sigma^2/2 + sigma^2/(16*W^2));
        term2 = 2 * W * sigma;
        term3 = erfc(sigma/(4*W));
        EIt = (term1 ./ term2) .* term3;
        
        % 绘制曲线
        plot(sigma_range, EIt, 'Color', colors(i,:), 'LineWidth', 2);
        legend_entries{i} = ['W = ' num2str(W)];
    end
    
    % 添加图例
    legend(legend_entries, 'Location', 'best');
    
    % 设置y轴范围
    ylim([0 max(EIt)*1.1]);
    
    hold off;
end