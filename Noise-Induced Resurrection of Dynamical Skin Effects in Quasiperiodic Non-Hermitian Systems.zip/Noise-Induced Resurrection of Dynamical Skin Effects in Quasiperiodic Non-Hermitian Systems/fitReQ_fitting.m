clc
clear
jr=2;
jl=1;
L=50;       % L是总共的格点数
W=5;
%W=[2,4,6,8,10];

% 噪声参数设置
T_total = 100;    % 总时间
theta = 1.0;      % 均值回归速度
mu = 0.0;         % 长期均值
sigma = 2:0.5:10;  % 波动率
X0 = 0;           % 初始值

% ==================================================================
% 关键修改1：生成对数间隔时间网格（短时间高分辨率，长时间低分辨率）
num_points = T_total*10;
t = linspace(0, T_total, num_points)'; % 对数间隔时间点
dt = diff(t);                 % 自适应时间步长数组
% ==================================================================
ensemble=10; % 系综次数
% ========== 新增：定义颜色和线型 ==========
colors = lines(length(W)); % 不同颜色
% =======================================


figure(1)
hold on

for aa = 1:length(sigma)

    Pt_all = zeros(length(t),L);
    for ii=1:ensemble % 使用并行加速
        total_ou_process = zeros(L, length(t));
        initial_state = zeros(L,1);
        initial_state(round(L/2)) = 1;

        % 生成OU过程路径（预生成所有时间点）
        for jj=1:L
            ou_path = simulate_ou_process_adaptive(t, theta, mu, sigma(aa), X0);
            total_ou_process(jj,:) = ou_path;
        end

        T_state = initial_state;
        % ==================================================================
        H0 = Hatano_Nelson_H(jr,jl,L,W);
        for tt=1:length(t)-1
            % 构造含噪声的哈密顿量
            H = H0;
            for jj=1:L
                H(jj,jj) = H(jj,jj) + total_ou_process(jj,tt);
            end

            % 使用当前时间步长dt(tt)进行演化
            T_state = expm(-1i*H*dt(tt)) * T_state;
            T_state = T_state./norm(T_state);
            Pt = abs(T_state).^2;
            %利用最小二乘法计算t时刻的有效扩散系数
            Pt_all(tt,:) = Pt_all(tt,:) + Pt';
        end
    end
end
Pt_all = Pt_all./ensemble;
Delta = 0.5*(jr-jl);
J = 0.5*(jr+jl);
ReQ = fitReQ_updated(t, Pt_all, Delta, J);
