clc
clear
t1=2;
t2=1;
gama=1;
fai1=pi/2;    % 修改为标量除法
fai2=-pi/2;   % 修改为标量除法
L=100;
W=4;

RE_Ea=-1.2:0.1:1.2;
IM_Ea=-4:0.1:4;
P_collection=zeros(length(RE_Ea),length(IM_Ea));
for ii=1:length(RE_Ea)
    parfor jj=1:length(IM_Ea)
        Ea=RE_Ea(ii)+1i*IM_Ea(jj);
        p=gain_loss_Flux_Bott(t1, t2, fai1, fai2, gama, W, L, Ea);
        P_collection(ii,jj)=p;
    end
end

figure(1)
[X,Y]=meshgrid(RE_Ea,IM_Ea);
surface(X,Y,real((P_collection')));
colorbar
xlabel('Re(Ea)')
ylabel('Im(Ea)')
%title('P')
shading interp %使更光滑
yticks(linspace(-4, 4, 5)); % linspace生成从0到5之间的6个等分点
xticks(linspace(-1.2,1.2, 5));
