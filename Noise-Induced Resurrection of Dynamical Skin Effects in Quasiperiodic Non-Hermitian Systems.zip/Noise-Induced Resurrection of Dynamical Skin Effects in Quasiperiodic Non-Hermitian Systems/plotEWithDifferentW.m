function plotEWithDifferentW(W_list, sigma_range)
% 绘制不同W值下的函数曲线
% 输入参数：
%   W_list: W值数组，例如[0.5, 1, 2, 4]
%   sigma_range: σ的范围，例如linspace(0.1, 5, 100)

figure;
hold on;

for i = 1:length(W_list)
    W = W_list(i);
    % 计算公式各组成部分
    term1 = sqrt(pi) * exp(sigma_range.^2/(16*W^2));
    denominator = 2 * W * sigma_range;
    term2 = erfc(sigma_range/(4*W));
    
    % 计算期望值
    E = (term1 ./ denominator) .* term2;
    
    % 绘制曲线
    plot(sigma_range, E, 'LineWidth', 1.5, 'DisplayName', sprintf('W = %.2f', W));
end

hold off;
xlabel('\sigma');
ylabel('\mathbb{E}[I(t)]');
title('不同W值的期望函数曲线');
legend('show');
grid on;
end