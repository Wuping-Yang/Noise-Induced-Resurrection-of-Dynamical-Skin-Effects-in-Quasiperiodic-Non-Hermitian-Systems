function H=gain_loss_NHSE(t1,t2,t3,gama,W,L,index)
%这里index取1时，H是PBC的；取0时H是OBC的
sigema0 = [1,0;0,1];
sigemaX = [0,1;1,0];
sigemaY = [0,-1i;1i,0];
sigemaZ = [1,0;0,-1];

incell = t1*sigemaX - 1i*gama*sigemaZ;
T1 = 0.5*t2*sigemaX + 0.5*1i*t2*sigemaY - 1i*t3*sigema0;
T2 = 0.5*t2*sigemaX - 0.5*1i*t2*sigemaY + 1i*t3*sigema0;

H=zeros(2*L);
alpha = (sqrt(5)-1)./2;

for ii=1:L
    for jj=1:L

        %原胞内部
        if ii==jj
            H((2*ii-1):2*ii , (2*jj-1):2*jj) = incell + eye(2)*W*cos(2*pi*alpha*jj);
        end

        %正方向的hopping
        if ii==jj+1
            H((2*ii-1):2*ii , (2*jj-1):2*jj) = T1;
        end
        %负方向的hopping
        if ii+1==jj
            H((2*ii-1):2*ii , (2*jj-1):2*jj) = T2;
        end


        if index==1
            %取PBC
            %X方向的面接起来
            if ii==L && jj==1
                H((2*ii-1):2*ii , (2*jj-1):2*jj) = T2;
            end

            if ii==1 && jj==L
                H((2*ii-1):2*ii , (2*jj-1):2*jj) = T1;
            end


        end

    end
end

