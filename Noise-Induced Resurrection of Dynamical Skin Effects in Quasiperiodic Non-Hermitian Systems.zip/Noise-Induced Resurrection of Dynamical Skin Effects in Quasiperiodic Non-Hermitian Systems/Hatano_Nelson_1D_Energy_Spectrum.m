clc;clear
jr=1;
jl=2;
L=100;  %L���ܹ��ĸ����
W=0;
H1=Hatano_Nelson_H(jr,jl,L,W);
H2=Hatano_Nelson_H_Periodicity(jr,jl,L,W);
AbsE1=zeros(1,L);
AbsE2=zeros(1,L);
[V1,E1]=eig(H1);
[V2,E2]=eig(H2);
states=1:L;

%����real��E���� imag(E)��ͼ��
RE1=zeros(L,1);
IE1=zeros(L,1);
RE2=zeros(L,1);
IE2=zeros(L,1);
for ii= 1:L
    RE1(ii)=real(E1(ii,ii));
    IE1(ii)=imag(E1(ii,ii));
    RE2(ii)=real(E2(ii,ii));
    IE2(ii)=imag(E2(ii,ii));
end


figure(2)
sz = 25;
subplot(1,2,1)
scatter(RE1,IE1,sz,'filled','b');
ylabel('Im[E]');
xlabel('Re[E]');
title(sprintf("OBC Energy Spectrum"))

subplot(1,2,2)
scatter(RE2,IE2,sz,'filled','r');
ylabel('Im[E]');
xlabel('Re[E]');
title(sprintf("PBC Energy Spectrum"))
ylim([-1.2 1.2])

sgtitle(sprintf("W=%d ",W))