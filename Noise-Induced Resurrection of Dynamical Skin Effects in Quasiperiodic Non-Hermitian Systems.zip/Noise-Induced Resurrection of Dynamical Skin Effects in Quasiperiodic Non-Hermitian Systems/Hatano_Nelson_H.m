function H=Hatano_Nelson_H(jr,jl,L,W)
JR=ones(1,L-1)*jr;
JL=ones(1,L-1)*jl;
H=diag(JR,-1)+diag(JL,1) ;

alpha = (sqrt(5)-1)./2;
for jj=1:L
    H(jj,jj) = W*cos(2*pi*alpha*jj);
end

end

