function H=Hatano_Nelson_H_Periodicity2(jr,jl,L,W)
JR=ones(1,L-1)*jr;
JL=ones(1,L-1)*jl;
H=diag(JR,1)+diag(JL,-1)+...
    kron(diag(1,L-1),jl)+kron(diag(1,-(L-1)),jr);

alpha = (sqrt(5)-1)./2;
for jj=1:L
    H(jj,jj) = W*randn;
end

end

