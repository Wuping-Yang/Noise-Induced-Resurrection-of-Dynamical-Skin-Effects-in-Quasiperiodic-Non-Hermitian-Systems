clc
clear
jr=2;
jl=1;
L=100;  %L是总共的格点数
W=10;

% 噪声参数设置
T = 100;       % 总时间
dt = 0.1;    % 时间步
theta = 1;  % 均值回归速度(这个一项如果调的很大的话，应当将时间步长调小)
mu = 0;     % 长期均值
sigma = 0;  % 波动率
X0 = 0;     % 初始值
t = 0:dt:T; % 时间向量

total_ou_process=zeros(L,length(t));
%构建初态（局域在体系中心处的一个波包）
initial_state=zeros(L,1);
initial_state(L./2)=1;

%定义t时刻的瞬时哈密顿量,并计算演化波函数
for ii=1:L
    %total_ou_process(ii,:)= simulate_ou_process(T, dt, theta, mu, sigma, X0);
     total_ou_process(ii,:)= simulate_ou_process_adaptive(t, theta, mu, sigma, X0);
    %total_ou_process(ii,:) = sigma*rand(1,length(t));
end


T_state=initial_state;
T_state_colletion=zeros(L,length(t));
H=Hatano_Nelson_H2(jr,jl,L,W);
for tt=1:length(t)
    for ii=1:L
        H(ii,ii)=H(ii,ii)+ total_ou_process(ii,tt);
    end
    T_state=expm(-1i*H*dt)*T_state;
    T_state=T_state./norm(T_state);
    T_state_colletion(:,tt)=T_state;
end

figure(1) 
[X,Y] = meshgrid(1:L,t);
surf(X, Y, abs(T_state_colletion'), 'EdgeColor', 'none');  % 'filled'表示填充点
colormap(jet);                    % 选择颜色映射（如jet, hot, parula）
colorbar;                         % 显示颜色条
xlabel('Site');
ylabel('Time');
% light;               % 添加光源
% lighting gouraud;    % 平滑光照
% material dull;       % 关闭镜面反射
