function df_dsigma = compute_derivative(sigma, W, beta)
% 计算函数 f(sigma) = (sigma/(4*W^2*sin(pi*beta)^2)) * ln(1 + (4*W^2*sin(pi*beta)^2)/sigma^2) 的导数值
% 输入:
%   sigma - 自变量值
%   W - 参数W
%   beta - 参数beta
% 输出:
%   df_dsigma - 函数在给定sigma处的导数值

    % 计算公共部分
    denominator = 4 * W^2 * sin(pi * beta)^2;
    
    % 计算对数部分
    log_part = log(1 + denominator / sigma^2);
    
    % 计算导数
    df_dsigma = log_part / denominator + ...
                (sigma / denominator) * ...
                (-2 * denominator / (sigma^3 * (1 + denominator / sigma^2)));
    
    % 简化表达式
    df_dsigma = log_part / denominator - ...
                2 / (sigma^2 + denominator / sigma);
end