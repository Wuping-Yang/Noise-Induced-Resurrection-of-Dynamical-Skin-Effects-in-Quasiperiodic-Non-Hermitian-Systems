function plotMultipleW(beta, W_values)
    % 参数设置
    u_min = 0;                  % 最小u值
    u_max = 10;                   % 最大u值
    num_points = 1000;            % 点数
    colors = lines(length(W_values)); % 不同颜色
    
    % 创建u值数组
    u = linspace(u_min, u_max, num_points);
    
    % 创建图形
    figure('Position', [100, 100, 900, 600]);
    hold on;
    grid on;
    
    % 初始化极值点存储
    max_points = zeros(length(W_values), 2);
    
    % 循环处理每个W值
    for i = 1:length(W_values)
        W = W_values(i);
        c = 4 * W^2 * sin(pi*beta)^2;  % 计算常数c
        
        % 计算函数值 f(u)
        f = (u.^2 / c) .* log(1 + c ./ u.^4);
        
        % 计算导数值 f'(u)
        term1 = 2 * log(1 + c ./ u.^4);
        term2 = 4 * c ./ (u.^4 + c);
        dfdu = (u / c) .* (term1 - term2);
        
        % 寻找极值点 (导数为零的点)
        [~, idx] = min(abs(dfdu));  % 寻找最接近零的点
        u_opt = u(idx);
        f_opt = f(idx);
        max_points(i, :) = [u_opt, f_opt];
        
        % 绘制函数曲线
        plot(u, f, 'Color', colors(i, :), 'LineWidth', 2, ...
            'DisplayName', sprintf('W = %.1f', W));
        
        % 标记极值点 (使用更小的红点)
        plot(u_opt, f_opt, 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
        text(u_opt, f_opt, sprintf(' u=%.2f', u_opt), ...
            'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', ...
            'FontSize', 9, 'Color', colors(i, :));
    end
    
    % 添加标签和图例 (只包含W值信息)
    xlabel('$u = \sigma / \theta$', 'Interpreter', 'latex', 'FontSize', 14);
    ylabel('$f(u) = \frac{1}{c}u^2\ln(1+c/u^4)$', 'Interpreter', 'latex', 'FontSize', 14);
    title(['Function Behavior for $\beta = ', num2str(beta), '$'], ...
        'Interpreter', 'latex', 'FontSize', 16);
    legend('show', 'Location', 'best');
    
    % 添加网格和美化
    set(gca, 'FontSize', 12);
    box on;
    grid minor;
    
    % 添加信息框
    annotation('textbox', [0.15, 0.75, 0.2, 0.1], 'String', ...
        sprintf('$c = 4W^2 \\sin^2(\\pi\\beta)$\n$\\beta = %.2f$', beta), ...
        'Interpreter', 'latex', 'FontSize', 12, ...
        'BackgroundColor', [1, 1, 1, 0.7], 'EdgeColor', 'none');
    
    hold off;
    
    % 绘制导数图（单独窗口）
    figure('Position', [150, 150, 900, 400]);
    hold on;
    grid on;
    
    for i = 1:length(W_values)
        W = W_values(i);
        c = 4 * W^2 * sin(pi*beta)^2;
        
        % 计算导数值 f'(u)
        term1 = 2 * log(1 + c ./ u.^4);
        term2 = 4 * c ./ (u.^4 + c);
        dfdu = (u / c) .* (term1 - term2);
        
        % 绘制导数曲线
        plot(u, dfdu, 'Color', colors(i, :), 'LineWidth', 1.5, ...
            'DisplayName', sprintf('W = %.1f', W));
        
        % 标记零点 (使用更小的红点)
        plot(max_points(i, 1), 0, 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
    end
    
    % 添加标签
    plot([u_min, u_max], [0, 0], 'k--', 'LineWidth', 1);  % 零点参考线
    xlabel('$u = \sigma / \theta$', 'Interpreter', 'latex', 'FontSize', 14);
    ylabel("$f'(u)$", 'Interpreter', 'latex', 'FontSize', 14);
    title('Derivative of the Function', 'FontSize', 16);
    legend('show', 'Location', 'best');
    set(gca, 'FontSize', 12);
    box on;
    grid minor;
end
