clc
clear
sigma = 10;    % 参数 σ
theta = 1;    % 参数 θ
beta = (sqrt(5)-1)./2;     % 参数 β
W_param = 5;  % 参数 W（表达式中的 W）
Delta = 0.5;    % 参数 Δ
J = 1.5;        % 参数 J
L=120;
boundary_type1 = 'periodic';
boundary_type2= 'open';
EE1=[];
EE2=[];

H1 = generate_W_matrix(L, sigma, theta, beta, W_param, Delta, J, boundary_type1)';
EE1=eig(H1);

jr = J + Delta;
jl = J - Delta;
H2 = Hatano_Nelson_H_Periodicity(jr,jl,L,W_param);
EE2=eig(H2);

% 创建图形
figure(1)
sz = 20;
% 创建第一个坐标轴（左侧和底部）
ax1 = axes;
scatter(ax1, real(EE1), imag(EE1), sz, 'filled', 'MarkerFaceColor', [0 0.4470 0.7410]) % 蓝色
xlabel(ax1, 'Real(EE1)')
ylabel(ax1, 'Imag(EE1)')
ax1.XColor = [0 0.4470 0.7410];
ax1.YColor = [0 0.4470 0.7410];

% 创建第二个坐标轴（右侧和顶部）
ax2 = axes('Position', ax1.Position, ...
           'XAxisLocation', 'top', ...
           'YAxisLocation', 'right', ...
           'Color', 'none', ...
           'XColor', [0.8500 0.3250 0.0980], ...
           'YColor', [0.8500 0.3250 0.0980]);
hold(ax2, 'on')
scatter(ax2, real(EE2), imag(EE2), sz, 'filled', 'MarkerFaceColor', [0.8500 0.3250 0.0980]) % 橙色
xlabel(ax2, 'Real(EE2)')
ylabel(ax2, 'Imag(EE2)')
fontsize(gcf,15,"points")
set(gca, 'LineWidth', 1.5);
grid on
box on
% % 链接两个坐标轴的位置，确保它们重叠
% linkaxes([ax1, ax2], 'xy')
% 
% % 确保第一个坐标轴在最前面
% uistack(ax1, 'top')

% % 调整视图
% hold(ax1, 'off')
% hold(ax2, 'off')