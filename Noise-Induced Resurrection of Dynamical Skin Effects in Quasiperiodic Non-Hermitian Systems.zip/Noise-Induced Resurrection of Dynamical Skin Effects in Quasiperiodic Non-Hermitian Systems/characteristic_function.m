clc
clear
% 定义不同的a值和x范围
a_values = [0.5, 1, 2];  % 不同的a值
x = linspace(0, 5, 500);  % x的范围：0到5，500个点

% 创建图形窗口
figure;
hold on;  % 保持图形，允许多条曲线叠加

% 循环绘制不同a值的曲线
colors = ['r', 'g', 'b'];  % 曲线颜色
line_styles = {'-', '--', ':'};  % 曲线样式
legend_labels = cell(1, length(a_values));  % 图例标签

for i = 1:length(a_values)
    a = a_values(i);
    f = (a^2) ./ (a^2 + x.^2);
    
    % 绘制曲线
    plot(x, f, 'Color', colors(i), 'LineStyle', line_styles{i}, 'LineWidth', 2);
    
    % 记录图例标签
    legend_labels{i} = ['a = ', num2str(a)];
end

% 添加图形标注
xlabel('x (x > 0)');
ylabel('f(x)');
title('函数图像: f(x) = a^2 / (a^2 + x^2) 不同a值对比');
legend(legend_labels, 'Location', 'northeast');  % 显示图例
grid on;
hold off;  % 关闭图形保持