function [sigma, f, df_dsigma] = compute_f_derivative(w, beta, sigma_range, plot_flag)
% 计算函数 <f>(sigma) 及其导函数，并可选绘图
% 输入:
%   w: 振荡强度参数 (标量或向量)
%   beta: 无理旋转参数 (默认: (sqrt(5)-1)/2)
%   sigma_range: [sigma_min, sigma_max] (默认: [0.1, 5])
%   plot_flag: 是否绘图 (true/false, 默认: true)
% 输出:
%   sigma: 计算的sigma点
%   f: 函数值 <f>(sigma)
%   df_dsigma: 导数值 d<f>/d(sigma)

% 默认参数处理
if nargin < 2 || isempty(beta)
    beta = (sqrt(5)-1)/2; % 默认黄金分割倒数
end
if nargin < 3 || isempty(sigma_range)
    sigma_range = [0.1, 5];
end
if nargin < 4
    plot_flag = true;
end

% 计算常数C
C = 4 * w.^2 * sin(pi*beta)^2;

% 生成sigma点 (对数间隔更佳)
sigma = logspace(log10(sigma_range(1)), log10(sigma_range(2)), 500);

% 预分配内存
f = zeros(length(w), length(sigma));
df_dsigma = zeros(length(w), length(sigma));

% 计算函数值和导数值
for i = 1:length(w)
    Ci = C(i);
    % 函数值
    f(i,:) = (sigma ./ Ci) .* log(1 + Ci ./ sigma.^2);
    
    % 导数值 (解析表达式)
    df_dsigma(i,:) = (1./Ci).*log(1 + Ci./sigma.^2) - 2./(sigma.^2 + Ci);
end

% 绘图
if plot_flag
    figure;
    
    % 绘制函数曲线
    subplot(2,1,1);
    hold on;
    colors = lines(length(w));
    for i = 1:length(w)
        plot(sigma, f(i,:), 'Color', colors(i,:), 'LineWidth', 1.5, ...
            'DisplayName', sprintf('w=%.2f', w(i)));
    end
    xlabel('\sigma');
    ylabel('\langle f \rangle(\sigma)');
    title(['平均函数 \langle f \rangle(\sigma) (beta=', num2str(beta), ')']);
    legend('Location', 'best');
    set(gca, 'XScale', 'log');
    grid on;
    hold off;
    
    % 绘制导数曲线
    subplot(2,1,2);
    hold on;
    for i = 1:length(w)
        plot(sigma, df_dsigma(i,:), 'Color', colors(i,:), 'LineWidth', 1.5, ...
            'DisplayName', sprintf('w=%.2f', w(i)));
        % 标记导数为零的点 (极值点)
        zero_idx = find(diff(sign(df_dsigma(i,:))));
        for j = 1:length(zero_idx)
            idx = zero_idx(j);
            plot(sigma(idx), df_dsigma(i,idx), 'ro', 'MarkerSize', 8);
            text(sigma(idx), df_dsigma(i,idx), ...
                sprintf(' \\sigma_{peak}=%.2f', sigma(idx)), ...
                'VerticalAlignment', 'bottom');
        end
    end
    xlabel('\sigma');
    ylabel('d\langle f \rangle/d\sigma');
    title('导函数曲线及极值点');
    legend('Location', 'best');
    set(gca, 'XScale', 'log');
    grid on;
    hold off;
end
end