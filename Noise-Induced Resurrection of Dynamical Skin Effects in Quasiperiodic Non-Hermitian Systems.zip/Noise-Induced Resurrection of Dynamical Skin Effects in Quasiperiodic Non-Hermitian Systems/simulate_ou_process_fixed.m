% OU过程模拟函数（固定时间步长）
function ou_path = simulate_ou_process_fixed(t, theta, mu, sigma, X0)
    dt = t(2) - t(1);
    ou_path = zeros(size(t));
    ou_path(1) = X0;
    
    for i = 2:length(t)
        dW = sqrt(dt) * randn;
        ou_path(i) = ou_path(i-1) + theta * (mu - ou_path(i-1)) * dt + sigma * dW;
    end
end