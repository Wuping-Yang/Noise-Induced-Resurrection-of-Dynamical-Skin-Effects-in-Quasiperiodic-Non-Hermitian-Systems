clc
clear
jr = 2;
jl = 1;
L = 10;          % 格点数
W = 0;

% 噪声参数
T = 100;         % 总时间
dt = 1;          % 时间步长
theta = 1.0;     % 均值回归速度
mu = 0.0;        % 长期均值
sigma = 0;       % 波动率
X0 = 0;          % 初始值
t = 0:dt:T;      % 时间向量
ensemble = 100;   % 系综数

%for aa = 1:ensemble
% 每个迭代生成独立的 OU 过程
total_ou_process_local = zeros(L, length(t));

for bb = 1:L
    total_ou_process_local(bb, :) = simulate_ou_process(T, dt, theta, mu, sigma, X0);
end

Vt = eye(L);
for tt = 1:length(t)
    % 构建含噪声的哈密顿量
    H = Hatano_Nelson_H(jr, jl, L, W);
    for cc = 1:L
        H(cc, cc) = H(cc, cc) + total_ou_process_local(cc, tt);
    end

    % 时间演化
    Mt = expm(-1i * H * dt) ;
    Vt = Mt*Vt;
end

%[U,D]=eig(Vt*Vt')
Heff=-(1/2*T)*log(Vt*Vt');


[UA,sigema,UB] = svd(Heff);

projection_A=diag([ones(1,L) , zeros(1,L)]);
projection_B=diag([zeros(1,L), ones(1,L)]);

position_operator=zeros(L);
for ii=1:L
    position_operator(ii,ii)=exp(1i*2*pi*(1/L)*ii);
end


XA=inv(UA)*position_operator*UA;
XB=inv(UB)*position_operator*UB;

Bott=trace(logm((XA*inv(XB))))*(2*pi*1i)^(-1)

