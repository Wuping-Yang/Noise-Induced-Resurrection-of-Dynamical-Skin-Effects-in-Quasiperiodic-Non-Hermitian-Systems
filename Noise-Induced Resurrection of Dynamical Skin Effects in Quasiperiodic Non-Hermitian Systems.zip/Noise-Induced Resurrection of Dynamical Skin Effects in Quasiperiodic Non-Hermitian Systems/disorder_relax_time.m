clc
clear
jr=2;
jl=1;
L=100;       % L是总共的格点数

% 噪声参数设置
T_total = 10^6;    % 总时间
theta = 1.0;      % 均值回归速度
mu = 0.0;         % 长期均值
X0 = 0;           % 初始值

sigma = 0.1:0.1:10;  % 波动率
W = 0.1:0.1:10;
% ==================================================================
% 关键修改1：生成对数间隔时间网格（短时间高分辨率，长时间低分辨率）
num_points = 10^7;              % 总时间点数
t_min = 1e-5;                 % 最小时间（避免t=0）
t = logspace(log10(t_min), log10(T_total), num_points)'; % 对数间隔时间点
t = [0; t];                   % 包含t=0（初始时刻）
dt = diff(t);                 % 自适应时间步长数组
% ==================================================================

ensemble = 10; % 系综次数


TC = zeros(length(sigma),length(W));
for aa = 1:length(sigma)
    parfor bb = 1:length(W)

        %avg_pos_all = zeros(ensemble, length(t));

        for ii=1:ensemble % 使用并行加速
            total_ou_process = zeros(L, length(t));
            initial_state = zeros(L,1);
            initial_state(round(L/2)) = 1;

            % 生成OU过程路径（预生成所有时间点）
            for jj=1:L
                ou_path = simulate_ou_process_adaptive(t, theta, mu, sigma(aa), X0);
                total_ou_process(jj,:) = ou_path;
            end

            T_state = initial_state;
            avg_pos_temp = zeros(1, length(t));

            % ==================================================================
            % 关键修改2：自适应时间步长循环
            for tt=1:length(t)-1
                % 构造含噪声的哈密顿量
                H = Hatano_Nelson_H2(jr,jl,L,W(bb));
                for jj=1:L
                    H(jj,jj) = H(jj,jj) + total_ou_process(jj,tt);
                end

                % 使用当前时间步长dt(tt)进行演化
                T_state = expm(-1i*H*dt(tt)) * T_state;
                T_state = T_state./norm(T_state);

                % 计算位置平均值
                positions = (1:L)';
                prob = abs(T_state).^2;
                avg_pos_temp(tt+1) = sum(positions .* prob);
                DT = abs(avg_pos_temp(tt+1) - avg_pos_temp(tt));

                if t(tt) > 1 && DT < 10^(-1)
                    TC(aa,bb) = TC(aa,bb) + t(tt);
                    break
                end
            end
        end

    end
end

TC = TC./ensemble;
figure(1)
[X,Y] = meshgrid(sigma,W);
s = surf(X,Y,TC')
colorbar
% 设置颜色风格
colormap('hot');
s.EdgeColor = 'none';