function Bott=gain_loss_Bott(t1,t2,t3,gama, W, L, Ea)
H = gain_loss_NHSE(t1,t2,t3,gama,W,L,0);

[m,~]=size(H);
h = H - Ea*eye(m);
[UA,~,UB] = svd(h);
position_operator=zeros(2*L);
for ii=1:L
    position_operator((2*ii-1),(2*ii-1))=exp((1i*2*pi/L)*ii);
    position_operator((2*ii),(2*ii))=exp((1i*2*pi/L)*ii);
end
XA=inv(UA)*position_operator*UA;
XB=inv(UB)*position_operator*UB;
Bott=trace(logm((XA*inv(XB))))*(2*pi*1i)^(-1);