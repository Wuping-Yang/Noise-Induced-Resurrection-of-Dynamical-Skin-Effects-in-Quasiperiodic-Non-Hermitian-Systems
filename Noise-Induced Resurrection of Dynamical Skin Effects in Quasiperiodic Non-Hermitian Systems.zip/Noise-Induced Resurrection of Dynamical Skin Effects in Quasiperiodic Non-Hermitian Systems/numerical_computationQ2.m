clc
clear

% 参数设置
jr = 2;
jl = 1;
L = 100;           % 格点数
theta = 1.0;       % 均值回归速度
mu = 0.0;          % 长期均值
sigma = 0:0.5:20;  % 波动率范围
X0 = 0;            % 初始值
ensemble = 500;     % 系综次数
num_points = 10000;  % 增加时间点数以提高精度

% W值设置
W_values = [2, 4, 6, 8, 10];
colors = lines(length(W_values)); % 不同颜色对应不同W值

% 目标平均位置
target_avg_pos = 75;

% 初始化存储结果
Q_results1 = zeros(length(sigma), length(W_values));
Q_results2 = zeros(length(sigma), length(W_values));
actual_T_total = zeros(length(sigma), length(W_values)); % 记录实际达到目标位置的时间

% 主循环
for bb = 1:length(W_values)
    W_current = W_values(bb);
    fprintf('Processing W = %d...\n', W_current);
    
    for aa = 1:length(sigma)
        sigma_current = sigma(aa);
        fprintf('  Processing sigma = %.1f...\n', sigma_current);
        
        Q_all1 = zeros(ensemble, 1);
        Q_all2 = zeros(ensemble, 1);
        T_total_all = zeros(ensemble, 1); % 记录每个系综的实际时间
        
        parfor ii = 1:ensemble
            % 生成OU过程
            % 先设置一个足够大的T_total_max以确保能达到目标位置
            T_total_max = 1000; % 最大模拟时间
            t = linspace(0, T_total_max, num_points)';
            dt = t(2) - t(1);
            
            total_ou_process = zeros(L, length(t));
            for jj = 1:L
                ou_path = simulate_ou_process_fixed(t, theta, mu, sigma_current, X0);
                total_ou_process(jj, :) = ou_path;
            end
            
            % 初始化态
            initial_state = zeros(L, 1);
            initial_state(round(L/2)) = 1;
            T_state = initial_state;
            
            % 时间演化
            reached_target = false;
            actual_time = T_total_max; % 默认值
            
            for tt = 1:length(t)-1
                % 构造哈密顿量
                H = Hatano_Nelson_H(jr, jl, L, W_current);
                
                % 添加噪声
                for jj = 1:L
                    H(jj, jj) = H(jj, jj) + total_ou_process(jj, tt);
                end
                
                % 时间演化
                T_state = expm(-1i * H * dt) * T_state;
                T_state = T_state / norm(T_state);
                
                % 检查是否达到目标平均位置
                positions = (1:L)';
                prob = abs(T_state).^2;
                avg_pos = sum(positions .* prob);
                
                if avg_pos >= target_avg_pos && ~reached_target
                    reached_target = true;
                    actual_time = t(tt);
                    
                    % 计算Q值
                    avg_pos_sq = sum(positions.^2 .* prob);
                    Q_val1 = (avg_pos_sq - avg_pos^2) / (4 * (1.5^2 + 0.5^2) * actual_time);
                    Q_val2 = avg_pos / (8 * 1.5 * 0.5 * actual_time);
                    
                    Q_all1(ii) = Q_val1;
                    Q_all2(ii) = Q_val2;
                    T_total_all(ii) = actual_time;
                    
                    % 提前终止这个系综的模拟
                    break;
                end
            end
            
            % 如果从未达到目标位置，使用最终状态计算
            if ~reached_target
                positions = (1:L)';
                prob = abs(T_state).^2;
                avg_pos = sum(positions .* prob);
                avg_pos_sq = sum(positions.^2 .* prob);
                Q_val1 = (avg_pos_sq - avg_pos^2) / (4 * (1.5^2 + 0.5^2) * T_total_max);
                Q_val2 = avg_pos / (8 * 1.5 * 0.5 * T_total_max);
                
                Q_all1(ii) = Q_val1;
                Q_all2(ii) = Q_val2;
                T_total_all(ii) = T_total_max;
            end
        end
        
        % 存储平均Q值
        Q_results1(aa, bb) = mean(Q_all1);
        Q_results2(aa, bb) = mean(Q_all2);
        actual_T_total(aa, bb) = mean(T_total_all);
        
        fprintf('    Average time to reach position %d: %.2f\n', target_avg_pos, actual_T_total(aa, bb));
    end
end

% 绘制图形
figure(1)
hold on
for bb = 1:length(W_values)
    plot(sigma, Q_results1(:, bb), 'o-', 'Color', colors(bb, :), 'LineWidth', 1.5, ...
        'DisplayName', sprintf('W = %d', W_values(bb)));
end
hold off

xlabel('\sigma', 'FontSize', 12);
ylabel('Q1', 'FontSize', 12);
title(sprintf('Q1 vs \\sigma when average position reaches %d', target_avg_pos), 'FontSize', 14);
legend('show', 'Location', 'best');
grid on;
box on;

% 绘制图形
figure(2)
hold on
for bb = 1:length(W_values)
    plot(sigma, Q_results2(:, bb), 'o-', 'Color', colors(bb, :), 'LineWidth', 1.5, ...
        'DisplayName', sprintf('W = %d', W_values(bb)));
end
hold off

xlabel('\sigma', 'FontSize', 12);
ylabel('Q2', 'FontSize', 12);
title(sprintf('Q2 vs \\sigma when average position reaches %d', target_avg_pos), 'FontSize', 14);
legend('show', 'Location', 'best');
grid on;
box on;

% 绘制达到目标位置所需时间
figure(3)
hold on
for bb = 1:length(W_values)
    plot(sigma, actual_T_total(:, bb), 'o-', 'Color', colors(bb, :), 'LineWidth', 1.5, ...
        'DisplayName', sprintf('W = %d', W_values(bb)));
end
hold off

xlabel('\sigma', 'FontSize', 12);
ylabel('Time to reach target position', 'FontSize', 12);
title(sprintf('Time to reach average position %d', target_avg_pos), 'FontSize', 14);
legend('show', 'Location', 'best');
grid on;
box on;