clc
clear
% 直接运行的脚本（非函数）
sigma = 1;
W_values = [0.5, 1, 2, 5];

figure;
hold on;
grid on;
xlabel('\sigma');
ylabel('E[I(t)]');
title(['E[I(t)] for different W values (\sigma = ' num2str(sigma) ')']);

sigma_range = linspace(0.1, 5, 100);
colors = lines(length(W_values));
legend_entries = cell(1, length(W_values));

for i = 1:length(W_values)
    W = W_values(i);
    term1 = sqrt(pi) * exp(sigma^2/2 + sigma^2/(16*W^2));
    term2 = 2 * W * sigma;
    term3 = erfc(sigma/(4*W));
    EIt = (term1 ./ term2) .* term3;
    plot(sigma_range, EIt, 'Color', colors(i,:), 'LineWidth', 2);
    legend_entries{i} = ['W = ' num2str(W)];
end

legend(legend_entries, 'Location', 'best');
ylim([0 max(EIt)*1.1]);
hold off;