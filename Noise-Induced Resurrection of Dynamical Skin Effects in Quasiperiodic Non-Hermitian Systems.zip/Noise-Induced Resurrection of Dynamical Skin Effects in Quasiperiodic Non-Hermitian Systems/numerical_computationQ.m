clc
clear

% 参数设置
jr = 2;
jl = 1;
L = 100;           % 格点数
T_total = 20;      % 总时间
theta = 1.0;       % 均值回归速度
mu = 0.0;          % 长期均值
sigma = 0:0.5:20;  % 波动率范围，增加点数使曲线更平滑
X0 = 0;            % 初始值
ensemble = 500;     % 减少系综次数以加快计算，可根据需要调整
num_points = 100;  % 时间点数

% W值设置
W_values = [2, 4, 6, 8, 10];
colors = lines(length(W_values)); % 不同颜色对应不同W值

% 初始化存储结果
Q_results1 = zeros(length(sigma), length(W_values));
Q_results2 = zeros(length(sigma), length(W_values));

% 时间网格
t = linspace(0, T_total, num_points)';
dt = t(2) - t(1); % 固定时间步长

% 主循环
for bb = 1:length(W_values)
    W_current = W_values(bb);
    fprintf('Processing W = %d...\n', W_current);
    
    for aa = 1:length(sigma)
        sigma_current = sigma(aa);
        fprintf('  Processing sigma = %.1f...\n', sigma_current);
        
        Q_all1 = zeros(ensemble, 1); % 只存储最终Q值
        Q_all2 = zeros(ensemble, 1); % 只存储最终Q值
        
        parfor ii = 1:ensemble % 使用并行计算加速
            % 生成OU过程
            total_ou_process = zeros(L, length(t));
            for jj = 1:L
                ou_path = simulate_ou_process_fixed(t, theta, mu, sigma_current, X0);
                total_ou_process(jj, :) = ou_path;
            end
            
            % 初始化态
            initial_state = zeros(L, 1);
            initial_state(round(L/2)) = 1;
            T_state = initial_state;
            
            % 时间演化
            for tt = 1:length(t)-1
                % 构造哈密顿量
                H = Hatano_Nelson_H(jr, jl, L, W_current);
                
                % 添加噪声
                for jj = 1:L
                    H(jj, jj) = H(jj, jj) + total_ou_process(jj, tt);
                end
                
                % 时间演化
                T_state = expm(-1i * H * dt) * T_state;
                T_state = T_state / norm(T_state);
            end
            
            % 计算最终Q值
            positions = (1:L)';
            prob = abs(T_state).^2;
            avg_pos = sum(positions .* prob);
            avg_pos_sq = sum(positions.^2 .* prob);
            Q_val1 = (avg_pos_sq - avg_pos^2) / (4 * (1.5^2 + 0.5^2) * T_total);
            Q_val2 = (avg_pos)./(8*1.5*0.5*T_total)

            
            Q_all1(ii) = Q_val1;
            Q_all2(ii) = Q_val2;
        end
        
        % 存储平均Q值
        Q_results1(aa, bb) = mean(Q_all1);
        Q_results2(aa, bb) = mean(Q_all2);
    end
end

% 绘制图形
figure(1)
hold on
for bb = 1:length(W_values)
    plot(sigma, Q_results1(:, bb), 'o-', 'Color', colors(bb, :), 'LineWidth', 1.5, ...
        'DisplayName', sprintf('W = %d', W_values(bb)));
end
hold off

xlabel('\sigma', 'FontSize', 12);
ylabel('Q', 'FontSize', 12);
title('Q1 vs \sigma for different W values', 'FontSize', 14);
legend('show', 'Location', 'best');
grid on;
box on;

% 绘制图形
figure(2)
hold on
for bb = 1:length(W_values)
    plot(sigma, Q_results2(:, bb), 'o-', 'Color', colors(bb, :), 'LineWidth', 1.5, ...
        'DisplayName', sprintf('W = %d', W_values(bb)));
end
hold off

xlabel('\sigma', 'FontSize', 12);
ylabel('Q', 'FontSize', 12);
title('Q2 vs \sigma for different W values', 'FontSize', 14);
legend('show', 'Location', 'best');
grid on;
box on;