% 清除环境
clear; clc; close all;

% --- Parameter Settings ---
sigma = 5; % σ
theta = 1; % θ
W = 10; % W
beta = (sqrt(5)-1)./2; % β (Golden Ratio)

% --- Range Setting for j ---
j_min = 0;
j_max = 100;
j = j_min:j_max;

% --- Calculation ---
% Calculate Re Q_{j, j+1}
sin_term1 = sin(pi * beta * (2*j + 1));
sin_term2 = sin(pi * beta);
denominator = sigma^4 + 4 * W^2 * theta^4 * sin_term1.^2 * sin_term2^2;
Re_Q = (sigma^2 * theta^2) ./ denominator;

% Calculate the average line for Re Q
Re_Q_avg = (sigma^2 * theta^2) / (sigma^4 + 2 * W^2 * theta^4 * sin(pi * beta)^2);

% --- Plotting and Customization ---
figure('Position', [100, 100, 1000, 600], 'Color', 'w'); % Set background color to white

% 绘制 Re Q_{j, j+1} (蓝色实线，粗细 2.5)
plot(j, Re_Q, 'Color', [0.1 0.4 0.7], 'LineWidth', 2.5, ...
     'DisplayName', 'Re Q_{j, j+1}', 'Marker', '.', 'MarkerSize', 10, 'MarkerIndices', 1:10:j_max+1);
hold on;

% 绘制平均值虚线 (红色虚线，粗细 3)
plot([j_min, j_max], [Re_Q_avg, Re_Q_avg], 'r--', 'LineWidth', 3, ... 
     'DisplayName', sprintf('Average Line: %.4f', Re_Q_avg));

% --- Figure Aesthetics ---

% Set axis labels and title (English, 加大加粗)
% 标签字体大小提升至 16
xlabel('$j$', 'Interpreter', 'latex', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('$\mathrm{Re} \ Q_{j, j+1}$', 'Interpreter', 'latex', 'FontSize', 16, 'FontWeight', 'bold');
% 标题字体大小提升至 18
title('$\mathrm{Re} \ Q_{j, j+1}$ \textbf{ vs. } $j$','Interpreter', 'latex', 'FontSize', 18, 'FontWeight', 'bold');

% Legend and Grid
% 图例字体大小提升至 14，并恢复边框 (Box: on)
legend('show', 'Location', 'NorthEast', 'FontSize', 14, 'Box', 'on'); 
grid on;
grid minor;
set(gca, 'GridAlpha', 0.5, 'MinorGridAlpha', 0.1); % Adjust grid transparency

% Set axis limits
xlim([j_min, j_max]);
ylim([min(Re_Q)*0.9, max(Re_Q)*1.1]);

% Final touches
% 坐标轴刻度字体大小提升至 14，边框粗细 1.5
set(gca, 'FontSize', 14, 'FontWeight', 'bold', 'LineWidth', 1.5); 
box on; % Draw a box around the plot