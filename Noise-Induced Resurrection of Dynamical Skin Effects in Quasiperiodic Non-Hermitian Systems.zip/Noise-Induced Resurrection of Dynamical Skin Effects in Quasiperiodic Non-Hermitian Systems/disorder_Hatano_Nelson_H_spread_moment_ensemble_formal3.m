clc
clear
jr=2;
jl=1;
L=100;       % L是总共的格点数
W=10;

% 噪声参数设置
T_total = 10^6;    % 总时间
theta = 1.0;      % 均值回归速度
mu = 0.0;         % 长期均值
sigma = [0.1, 10, 100 , 1000];  % 波动率
X0 = 0;           % 初始值

% ==================================================================
% 关键修改1：生成对数间隔时间网格（短时间高分辨率，长时间低分辨率）
num_points = 10^7;              % 总时间点数
t_min = 1e-5;                 % 最小时间（避免t=0）
t = logspace(log10(t_min), log10(T_total), num_points)'; % 对数间隔时间点
t = [0; t];                   % 包含t=0（初始时刻）
dt = diff(t);                 % 自适应时间步长数组
% ==================================================================

ensemble=10000; % 系综次数

% ========== 新增：定义颜色和线型 ==========
%colors = {'r', 'g', 'b'}; % 不同sigma对应颜色
%markerStyles = {'o', 's', 'd'};
colors = cell(length(sigma), 1);
colors{1} = 0.01*round(100*[092 158 173]./255);
colors{2} = 0.01*round(100*[210 204 161]./255);
colors{3} = 0.01*round(100*[206 190 190]./255);
colors{4} = 0.01*round(100*[237 177 131]./255);
% =======================================


figure(1)
hold on

for aa = 1:length(sigma)
    spread_all = zeros(ensemble, length(t)); 
    
    parfor ii=1:ensemble % 使用并行加速
        total_ou_process = zeros(L, length(t));
        initial_state = zeros(L,1);
        initial_state(round(L/2)) = 1;

        % 生成OU过程路径（预生成所有时间点）
        for jj=1:L 
            ou_path = simulate_ou_process_adaptive(t, theta, mu, sigma(aa), X0);
            total_ou_process(jj,:) = ou_path;
        end

        T_state = initial_state;
        spread_moment_temp = zeros(1, length(t)); 
        
        % ==================================================================
        % 关键修改2：自适应时间步长循环
        for tt=1:length(t)-1
            % 构造含噪声的哈密顿量
            H = Hatano_Nelson_H2(jr,jl,L,W);
            for jj=1:L 
                H(jj,jj) = H(jj,jj) + total_ou_process(jj,tt);
            end
            
            % 使用当前时间步长dt(tt)进行演化
            T_state = expm(-1i*H*dt(tt)) * T_state;
            T_state = T_state./norm(T_state);

            % 计算展宽矩
            positions = (1:L)';
            prob = abs(T_state).^2;
            avg_pos = sum(positions .* prob);
            avg_pos_sq = sum(positions.^2 .* prob);
            spread_moment_temp(tt+1) = sqrt(avg_pos_sq - avg_pos^2);
        end
        % ==================================================================
        
        spread_all(ii,:) = spread_moment_temp;
    end
    
    % 计算均值和标准差
    spread_mean = mean(spread_all, 1);
    spread_std = std(spread_all, 0, 1);
    
    % ==================================================================
    % 关键修改3：智能稀疏化采样（对数坐标均匀分布）
%     plot_indices = unique(round(logspace(0, log10(length(t)), 30))); % 30个均匀分布点
%     plot_indices(plot_indices > length(t)) = [];

    plot_indices = unique(round(linspace(1,length(t),50)));
    % ==================================================================
    
    % 绘图（仅绘制稀疏化后的点）
    errorbar(t(plot_indices), spread_mean(plot_indices), spread_std(plot_indices), ... 
        'Color', colors{aa}, ...
        'LineWidth', 2, ...              
        'MarkerSize', 6);
end

% 设置对数坐标轴
set(gca, 'XScale', 'log', 'YScale', 'log');
xlabel('Time (log scale)');
ylabel('Spread Moment (log scale)');
legend(cellstr(num2str(sigma', '\\sigma=%.1f')), 'Location', 'best');
grid on;