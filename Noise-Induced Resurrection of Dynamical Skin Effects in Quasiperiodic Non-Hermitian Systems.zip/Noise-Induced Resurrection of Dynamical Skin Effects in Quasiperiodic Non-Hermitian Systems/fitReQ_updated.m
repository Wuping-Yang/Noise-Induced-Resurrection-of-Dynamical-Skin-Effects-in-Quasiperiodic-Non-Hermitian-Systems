function ReQ = fitReQ_updated(t, P, Delta, J)
    % 输入:
    %   t: 时间向量 (M x 1)
    %   P: 场振幅矩阵 (M x N), 第j列对应格点j的数据
    %   Delta, J: 已知常数
    % 输出:
    %   ReQ: 拟合的系数
    
    [M, N] = size(P); % M时间步, N格点
    dPdt = zeros(M, N);
    
    % 计算每个格点的导数 (中心差分)
    for j = 1:N
        for i = 2:M-1
            dPdt(i,j) = (P(i+1,j) - P(i-1,j)) / (t(i+1) - t(i-1));
        end
        % 边界点用单侧差分
        dPdt(1,j) = (P(2,j) - P(1,j)) / (t(2) - t(1));
        dPdt(M,j) = (P(M,j) - P(M-1,j)) / (t(M) - t(M-1));
    end
    
    % 计算所有非边界格点的F_j(t)
    Y = []; % 存储导数
    X = []; % 存储F_j(t)
    for j = 2:N-1 % 忽略边界格点
        F_j = 2 * ( ...
            2*(Delta + J)*(Delta - J)*P(:,j) + ...
            (J + Delta)^2 * P(:,j+1) + ...
            (J - Delta)^2 * P(:,j-1) ...
        );
        Y = [Y; dPdt(:,j)]; % 拼接导数
        X = [X; F_j];       % 拼接F_j(t)
    end
    
    % 最小二乘法求解 Re(Q)
    ReQ = (X' * X) \ (X' * Y);
    
    fprintf('拟合结果: Re(Q) = %.6f\n', ReQ);
    
    % 绘制拟合效果 (示例: 第一个非边界格点j=2)
    j_plot = 2;
    figure;
    plot(t, dPdt(:,j_plot), 'b-', t, ReQ * X(1:M), 'r--');
    xlabel('时间 t');
    ylabel('导数');
    legend('实际导数', '拟合导数');
    title(sprintf('格点j=%d的导数拟合效果', j_plot));
end