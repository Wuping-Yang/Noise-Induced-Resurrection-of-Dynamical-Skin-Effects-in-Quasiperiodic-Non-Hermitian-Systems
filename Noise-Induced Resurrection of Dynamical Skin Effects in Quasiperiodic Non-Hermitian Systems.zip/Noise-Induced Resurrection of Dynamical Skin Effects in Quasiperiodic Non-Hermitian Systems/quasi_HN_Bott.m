function Bott=quasi_HN_Bott(jr,jl,L,W,Ea)
H=Hatano_Nelson_H(jr,jl,L,W);
h = H - Ea*eye(L);
[UA,sigema,UB] = svd(h);
position_operator=zeros(L);
for ii=1:L
    position_operator(ii,ii)=exp(1i*2*pi*(1/L)*ii);
end

XA=inv(UA)*position_operator*UA;
XB=inv(UB)*position_operator*UB;

Bott=trace(logm((XA*inv(XB))))*(2*pi*1i)^(-1);