clc
clear
jr=2;
jl=1;
LL=500;  %L是总共的格点数
W=0;

RE_E1=-4:0.1:4;
IM_E1=-1.5:0.1:1.5;
PX=zeros(length(RE_E1),length(IM_E1));
XBott=0;
for ii=1:length(RE_E1)
    parfor jj=1:length(IM_E1)
        XBott=skin_effect_1D_polarization(jr,jl,LL,W,RE_E1(ii)+1i*IM_E1(jj));
        PX(ii,jj)=XBott;
    end
end

figure(1)
[X,Y]=meshgrid(RE_E1,IM_E1);
surface(X,Y,real(PX'));
colorbar
ylabel('Im(Ea)');
xlabel('Re(Ea)');
title('Px')
shading interp %使更光滑
fontsize(gcf,17,"points")
cb = colorbar;
cb.Ticks = linspace(min(get(gca,'CLim')), max(get(gca,'CLim')), 5); % 设置为5个步长
